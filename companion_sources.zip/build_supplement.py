"""Build the reader-facing supplement from its portable, curated sources.

This command generates a document only. It never runs a radio service or an
experiment. Optional compilation uses an existing latexmk/TeX Live installation.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import re
import subprocess

HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def table_rows(block):
    return " ".join(block.split(r"\midrule", 1)[1].split(r"\bottomrule", 1)[0].split())


def tables(source):
    result = {}
    for block in re.findall(re.escape(r"\begin{table}") + ".*?" + re.escape(r"\end{table}"), source, re.S):
        label = re.search(re.escape(r"\label{") + r"([^}]+)", block)[1]
        if label in result:
            raise ValueError("Duplicate table label: " + label)
        result[label] = table_rows(block)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--compile", action="store_true", help="Compile with installed latexmk after generating TeX")
    parser.add_argument("--verify-project-root", type=Path, help="Additionally verify retained evidence hashes against a local project tree")
    args = parser.parse_args()
    contract = json.loads((HERE / "source_contract.json").read_text(encoding="utf-8"))
    parts = ["reader_preamble.tex", "model_methods.tex", "experimental_methods.tex", "reproduction.tex", "posthoc_analysis.tex", "concurrency_methods.tex"]
    document = "\n".join((HERE / name).read_text(encoding="utf-8") for name in parts)
    observed = tables(document)
    assert list(observed) == [r["label"] for r in contract["tables"]]
    for row in contract["tables"]:
        digest = hashlib.sha256(observed[row["label"]].encode()).hexdigest()
        assert digest == row["numeric_rows_sha256"], "Changed retained table data: " + row["label"]
    assert len(observed) == 19 and document.count(r"\begin{figure}") == 2
    assert contract['original_numeric_tables'] == 17
    assert [row['numeric_rows_sha256'] for row in contract['tables'][:17]] == contract['original_17_numeric_rows_sha256']
    assert r"\textcolor{red}" not in document and r"\color{red}" not in document
    assert not re.search(r"\b(?:reviewer|editor|post-review|resubmission|TODO|TBD)\b", document, re.I)
    assert not re.search(r"(?<![A-Za-z])[A-Za-z]:[/\\]|/mnt/[a-z]/|/home/|/Users/", document)
    labels = set(re.findall(re.escape(r"\label{") + r"([^}]+)", document))
    refs = set(re.findall(r"\\(?:ref|pageref)\{([^}]+)\}", document))
    assert refs <= labels, "Unresolved local reference: " + repr(refs - labels)
    for fig in contract["figures"]:
        assert sha(HERE / fig["bundled_file"]) == fig["sha256"]
    for item in contract["reader_extracts"]:
        assert sha(HERE / item["bundled_file"]) == item["sha256"]
    period_rows = list(csv.DictReader((HERE / 'data/kpm_period_fields.csv').open(encoding='utf-8', newline='')))
    assert len(period_rows) == 1067
    assert sum(r['decoded_granulPeriod_ms'] == '200' for r in period_rows) == 891
    assert sum(r['decoded_granulPeriod_ms'] == '1000' for r in period_rows) == 176
    assert all(r['requested_reporting_period_ms'] == r['requested_granularity_period_ms'] == r['decoded_granulPeriod_ms'] for r in period_rows)
    assert len({r['episode'] for r in period_rows}) == 12
    cells=[json.loads(line) for line in (HERE/'data/timing_grid_cells.jsonl').read_text(encoding='utf-8').splitlines() if line]
    assert len(cells)==720
    assert sum(r['pair']['additional_wait_s'] is not None and r['pair']['additional_wait_s']<0 for r in cells)==18
    if args.verify_project_root:
        for source in contract["retained_sources"]:
            path = args.verify_project_root / source["path"]
            assert path.is_file() and sha(path) == source["sha256"], "Retained source mismatch: " + source["path"]
    output = HERE / "technical_supplement.tex"
    output.write_text(document, encoding="utf-8", newline="\n")
    provenance = dict(contract)
    provenance.update(
        format="Reader-facing technical supplement; public selected-source companion",
        table_numbering="S1--S19", figure_numbering="S1--S2",
        all_17_retained_numeric_tables_unchanged=True,
        source_sha256={name: sha(HERE / name) for name in parts + ["build_supplement.py", "source_contract.json", "DATA_INDEX.md"]},
        generated_tex_sha256=sha(output),
        availability="Technical supplement and selected data and analysis code: https://github.com/ermalimust/oran-policy-outcomes-artifact . Full-project evidence paths are not all distributed in the public ZIP; see Section 9 and DATA_INDEX.md for scope.",
    )
    (HERE / "provenance_map.json").write_text(json.dumps(provenance, indent=2) + "\n", encoding="utf-8")
    if args.compile:
        result = subprocess.run(["latexmk", "-norc", "-pdf", "-interaction=nonstopmode", "-halt-on-error", output.name],
                                cwd=HERE, capture_output=True, text=True, encoding="utf-8", errors="replace")
        (HERE / "compile_stdout.log").write_text(result.stdout + result.stderr, encoding="utf-8")
        if result.returncode:
            raise RuntimeError("TeX compilation failed; inspect compile_stdout.log")
        log = (HERE / "technical_supplement.log").read_text(encoding="utf-8", errors="replace")
        critical = [line for line in log.splitlines() if any(key in line for key in
                    ("Overfull", "undefined references", "Missing character", "LaTeX Error"))]
        report = dict(status="passed" if not critical else "needs_layout_review", critical_messages=critical,
                      pdf_sha256=sha(HERE / "technical_supplement.pdf"), tex_sha256=sha(output),
                      retained_numeric_tables=17, total_numeric_tables=19, retained_figures=2)
        (HERE / "compile_report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
        if critical:
            raise RuntimeError("Inspect reported TeX layout/reference issues")
    print(json.dumps(dict(tables=len(observed), figures=2, output=output.name, compiled=args.compile)))


if __name__ == "__main__":
    main()
