# Technical supplement: O-RAN policies and measured outcomes

Companion material for **From O-RAN Policies to Measured Outcomes: Release and Recovery in Practice**.

Read the [technical supplement](technical_supplement.pdf) for the methods, **Tables S1-S19**, and **Figures S1-S2**. This repository contains its editable TeX sources, selected retained data, and a portable retrospective analysis. It is a bounded companion artifact, not a complete distribution of the radio platform or every raw experiment capture.

## What can be reproduced here

- **Document:** rebuild the complete 28-page supplement, including all 18 tables and two figures. The builder verifies table-row and bundled-file hashes.
- **Source-provenance rules and retrospective transitions:** rerun the unchanged evaluator on 1,067 normalized KPM reports and 48 actions from all 12 instrumented episodes, then reproduce the 60%-transition shadow decisions in Table S18 and the crossing-batch calculation in Section 10.
- **Retained outputs:** inspect all 720 delivery-timing rule pairs, their 90 aggregate groups, and the six pending-restoration arm/case counts. These outputs are included; their separate live raw inputs are not.

The package does **not** reproduce every table from raw inputs. [REPRODUCIBILITY.md](REPRODUCIBILITY.md) gives table-by-table coverage. The synthetic model/replay inputs, local-cost timing samples, full packet captures and complete service environment are outside this release. Normalized-input reanalysis is distinct from independently rejoining raw payloads or repeating a live experiment.

## Build the document

Requirements: Python 3 and TeX with `latexmk`/`pdflatex` and the standard packages listed in `reader_preamble.tex`. The Python builder uses only the standard library.

```text
python -B build_supplement.py --compile
```

This rebuilds the document without starting a service. The checked-in PDF is the clean supplement; no correspondence or comparison-copy document is included. TeX rebuilds may change PDF metadata bytes; generated TeX and protected table rows remain verifiable.

## Recompute the retrospective analysis

Run from the repository root with a new output directory:

```text
python -B posthoc/analyze_points_5_6.py --output results_recomputed
```

The script first reproduces all 48 original action outcomes with the frozen evaluator. It then applies the same low-threshold guards to copies of the 60% transition actions. That stage had no live low-state completion predicate. This is a **post-hoc shadow decision**, not an actual restoration proposal, E2 command, instantaneous radio truth, or failure of the retained 3-second controller.

All 12 planned episodes are retained: six with 1,000-ms reporting and six with 200-ms reporting. No unsuccessful shadow decision is removed. Input locations and driver hashes differ from the retained run metadata; scientific fields can be compared directly with `posthoc/results_retained/summary.json`.

## Files and interpretation

- [DATA_INDEX.md](DATA_INDEX.md): bundled inputs and separate evidence-tree references.
- [REPRODUCIBILITY.md](REPRODUCIBILITY.md): numerical reproduction limits.
- [source_contract.json](source_contract.json): protected table rows and data/figure hashes.
- [provenance_map.json](provenance_map.json): document source mapping.
- [PACKAGE_FILES.txt](PACKAGE_FILES.txt): curated file list.
- [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md): upstream attribution and applicable license.

The software-radio campaigns use one host, one UE and a software-radio path. Campaigns and post-hoc evaluations have distinct denominators. These results do not establish field reliability, a universal source-lag bound, or a benefit unique to a record representation. Raw-reference fields identify retained source records; they do not imply that those raw files are included here. Project-relative `revision/...` references in the PDF and provenance identify a separate evidence tree, not hidden paths on a reader's machine.

No blanket license is assigned to the authors' manuscript, figures, data or code. The included third-party source retains its own copyright and license.

The supplied PDF contains 28 pages. It includes Tables S1-S19 and Figures S1-S2.

Section 11 and Table S19 report a single-host concurrency test. The included retained data and code are described in `concurrency/README.md` inside the extracted archive. These measurements do not establish RAN control-path capacity or deployment-scale reliability.
