# Technical supplement: reader data index

This repository contains the curated files listed below. The relative `revision/...` paths identify a separate retained evidence tree; files are not bundled merely because they are referenced. See `REPRODUCIBILITY.md` for exact coverage. No machine-specific absolute path is required for document building or the included post-hoc reanalysis.

## Build this document

Use Python 3 and an installed TeX Live/latexmk:

```text
python build_supplement.py --compile
```

The default build reads only this folder's curated TeX, figures, data extracts and table contract. It does not require the separate project tree and does not start services.

`source_contract.json` contains the ordered hashes of all retained numerical table rows. `provenance_map.json` also identifies the curated source hashes and the original evidence files. An optional `--verify-project-root` argument checks those evidence hashes when the full retained project is available.

## Included reader extracts

- `data/timing_grid_cells.jsonl`: all 720 paired stage/grid evaluations, including unresolved results, 18 negative signed S-minus-H differences, and the original supporting report and source-batch IDs.
- `data/timing_grid_aggregate.csv`: all 90 delay/precision/wait/age aggregates; eight opportunities per row.
- `data/pending_restore_counts.csv`: T/B/D × no-successor/successor, three planned formal episodes per row.
- `figures/policy_update.pdf`: Figure S1, the retained actual A1/E2 policy-update trace.
- `figures/source_interval_pairs.pdf`: Figure S2, all paired decisions from the separate report-cadence/source-provenance matrix.

The extracts are analysis products from retained observations. They are not new runs, and the 720 grid cells are not 720 independent experiments.

## Numerical table sources

| Table | Project-relative retained source |
|---|---|
| S1 | `revision/artifact/results/revision_core/admission_metrics.csv` |
| S2 | `revision/artifact/results/revision_core/adjacent_paired_differences.csv` |
| S3 | `revision/artifact/results/revision_core/release_rate_matched_comparisons.csv` |
| S4 | `revision/artifact/results/revision_core/joint_admission_recovery.csv` |
| S5 | `revision/artifact/results/revision_lifecycle_matched/summary.json` |
| S6 | `revision/artifact/results/revision_core/frozen_stress_definition.json` |
| S7–S8 | `revision/artifact/results/revision_core/per_stress_metrics.csv` |
| S9 | `revision/artifact/results/revision_robustness/admission_sensitivity.csv` |
| S10 | `revision/artifact/results/revision_robustness/runtime_horizon_sensitivity.csv` |
| S11 | `revision/artifact/results/revision_robustness/tractor_freshness_sensitivity.csv` and `tractor_defer_causes.csv` |
| S12 | `revision/artifact/results/revision_robustness/local_batch_overhead.csv` and `record_storage_sizes.csv`; boundary audit: `revision/round2/magazine_readability/cost_audit.json` |
| S13–S14 | `revision/testbed/ric/analysis/cycles.csv` |
| S15 | `revision/round2/e2/formal_v1_retry1/independent_analysis/summary.json` |
| S16 | `revision/round2/stale_restore/results/readout_v1/summary.json` and `arm_case_counts.csv` |
| S17 | `revision/round2/timing_sensitivity/analysis/formal_v1/grid/summary.json`, with `formal_verification.json` in its analysis parent |
| S18 | `posthoc/results_retained/summary.json`; all 12 episodes retained |

## Methods and complete evidence sources

The model source is `revision/artifact/experiments/congestion_authorization/`, with the independent evaluator, visible-input gate adapter, generator configuration and lifecycle/replay analyses. The pinned model and replay packages are listed in `revision/artifact/requirements.txt`; the isolated numerical reproduction entry point is `revision/artifact/scripts/reproduce_revision.ps1`. A new output root preserves the retained results.

The normal E2 source is under `revision/testbed/`. The asynchronous A1/E2 campaign is `revision/round2/e2/formal_v1_retry1/`; external operator ledgers are retained under `revision/round2/a1/live_episodes/` for the same run IDs. Both campaigns lack exact RLC source intervals and should not be retrospectively treated as source-instrumented.

The report-cadence/source-interval experiment is `revision/round2/rlc_provenance/`: `protocol.md`, `formal_plan_v1.json`, the instrumented source patches, `campaigns/prov-formal-v1/`, packet verification, normalized source joins, and `results/readout_v1/`. The fixed counts are 12 episodes, 48 controls and 1,067 source-linked KPM reports.

The queued-restoration experiment is `revision/round2/stale_restore/`: `protocol.md`, `formal_plan_v1.json`, `campaigns/restore-formal-v1/`, `analysis/formal_v1_audit1/`, and `results/readout_v1/`. Its 18 formal episodes contain 45 policy controls plus 18 baseline-reset controls. The capture-level 981 KPM indications and 962 recorded measurements are distinct counts.

The delivery-timing experiment is `revision/round2/timing_sensitivity/`: `protocol.md`, `formal_plan_v1.json`, `campaigns/timing-formal-v1/` and `analysis/formal_v1/`. The probe captured 2,230 KPM indications, of which 2,125 entered source-linked analysis; the independent packet capture contains 2,244 indications. These are distinct observation layers. All 48 controls and 4,499 independent packet checks are retained. The `grid/` directory preserves 720 pairs/90 groups. The `independent_oracle/` directory checks all 1,440 rule outcomes and provides the negative-difference event trace. Delays occur after original report capture, not inside RLC production or provider refresh.

TRACTOR is an external observational input from `https://github.com/genesys-neu/TRACTOR`, commit `f2f052cbf541e25f561fae0a9ae8dbe4a9931702`. Its source identity and input hashes are pinned in `revision/artifact/configs/trace_replay.json`. The replay does not supply counterfactual action labels or measured action effects.

## Portable retrospective reanalysis

Run `python -B posthoc/analyze_points_5_6.py --output new_posthoc_output` from this folder. The new output directory must not exist. The script verifies the frozen evaluator against all 48 original action outcomes before applying the unchanged low predicate to a copy of each 60% transition. H0/S0 and both 3-second precision controls retain their gates; only the endpoint assignment is post-hoc. The retained 12-episode denominator includes six 1000-ms and six 200-ms episodes. No services or control sends occur.

For the crossing-batch diagnostic, nominal-period KPM values and actual wall-time counter rates are reported separately. Aggregate counts do not measure a byte split at configuration application. Subsequent steady rates do not measure instantaneous state at a shadow decision.
