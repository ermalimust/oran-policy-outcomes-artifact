# Retained local-sharding measurements

`retained_formal_v1.zip` contains all 48 formal attempts, including their raw
event responses, timing records, resource configurations, and final snapshots.
Extract it into the parent `concurrency` directory, then run the analyzer from
that directory:

```text
python -m zipfile -e portable/retained_formal_v1.zip .
python analyze_benchmark.py --campaign formal_v1 --output recomputed_analysis
```

This reaggregates retained local measurements. It does not rerun the benchmark
or start a RIC/RAN service. The parent README and frozen protocol define the
synthetic input workload and all measurement limitations.

`public_allowlist.json` binds the exact portable files and every archive entry.
`portability_check.json` records an isolated-directory extraction and verifies
that the regenerated numerical summary and both CSV files are byte-identical.
