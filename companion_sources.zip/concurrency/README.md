# Local per-resource sharding benchmark (Supplement Table S19)

This artifact retains all 48 planned local measurements: four load levels
(1, 4, 16, 64 simultaneously active resource candidates), three implementations
(T, B, D), and four repetitions. Each resource has its own unchanged original
worker process and full persistent snapshot. A shared machine processes bounded
bursts of synthetic lifecycle inputs. There is no RIC/RAN connection or radio
simulation in this benchmark.

The original worker has one current owner. The external harness partitions
independent resources into workers; it does not extend a single worker to manage
many resources or validate conflicting concurrent writers. ACK and KPM-like
records are declared synthetic fixtures. All real state transitions, validation
predicates, snapshot writes, flushes, fsync calls, and atomic replacements execute
in the retained worker code. Process startup is measured separately and excluded
from the lifecycle cost.

## Recompute Table S19 from retained raw measurements

Python 3.8 or later and its standard library are sufficient. Extract
`portable/retained_formal_v1.zip` in this directory. It creates `formal_v1/` with
all 48 attempts, 13,260 event records, 1,020 final snapshots and configurations,
warmup/probe records, environment metadata, and hash-bound manifests. Then run:

```text
python -m zipfile -e portable/retained_formal_v1.zip .
python analyze_benchmark.py --campaign formal_v1 --output recomputed_analysis
```

The analyzer refuses to overwrite an output directory, verifies every retained
file hash, checks planned versus attempted runs, recomputes latency and throughput,
and retains failed/missing runs in the denominator. `recomputed_analysis/` must
numerically match `analysis/formal_v1/`. Table S19 uses medians across four run
summaries, not a confidence interval from pooled events. All per-run metrics and
run ranges are included in the CSV files.

## Execute a new local benchmark

The formal plan binds the workload, protocol, runner, analyzer, and the five
unchanged runtime files. A new output directory preserves retained results:

```text
python run_benchmark.py run --plan formal_plan_v1.json --output rerun_local
python analyze_benchmark.py --campaign rerun_local --output rerun_analysis
```

This launches at most 64 Python child processes and writes per-resource snapshots
on the local disk. Measured timings depend on the new machine, OS, filesystem,
runtime, and background load, so a rerun need not reproduce identical latency
numbers. Do not run it in a directory containing retained results or interpret it
as a RAN deployment benchmark. No external services or network access are used.
The retained run used Windows 11, Python 3.14.5, and 24 logical processors.

## Files and measurement boundaries

- `protocol.md`, `workload.json`, `formal_plan_v1.json`: frozen design and schedule.
- `runtime/`: byte-identical original worker, common persistence/predicates, and
  three policy implementations. D means normalized tables within one process.
- `run_benchmark.py`: isolated process orchestration and raw event/timing capture.
- `analyze_benchmark.py`: raw-file verification and numerical reaggregation.
- `analysis/formal_v1/`: complete retained numerical summaries and run-level CSV.
- `portable/retained_formal_v1.zip`: every formal raw attempt, with no deletion
  or conversion of event and snapshot records.
- `portable/public_allowlist.json`: exact public file list and raw-archive hashes.

CPU values use the original process timer, which yielded 15.625 ms increments on
the retained Windows host. A zero event median does not establish zero CPU cost.
Primary latency measurements use the high-resolution performance counter. The
external dispatch wait is directly measured; the IPC/scheduling residual is not
an exact internal worker queue. Throughput is for finite synchronized bursts,
not sustained arrival saturation. Storage cost includes complete JSON snapshot
serialization and actual file-fsync/replace, without a power-loss durability test.

All 48 measured runs and all 1,020 candidates completed. These are local fixture
outcomes. They do not establish physical radio recovery, record-format superiority,
single-worker multi-resource capacity, or shared-resource race safety. Development
pilots are excluded from the formal archive and statistical denominators.

This directory makes no additional license grant. The surrounding artifact's
license and attribution notices apply; no third-party package is vendored here.
