# Local concurrent resource-worker benchmark

This finite processing benchmark addresses the cost of several active candidates
sharing one machine. It does not execute or emulate a RIC, E2 network, radio,
physical actuation, or concurrent writers to one resource.

## Architecture and frozen implementation

The retained T (transaction contexts), B (bound aggregate), and D (normalized
tables within a process) implementations each have exactly one current resource
owner. A later candidate in that worker supersedes the previous one. Consequently
the benchmark uses **N independent resource shards, each with its own unchanged
worker process, one candidate, configuration, and snapshot file**. It does not
add a multi-resource map to the original worker or claim that the original live
adapter already provides sharding. An external benchmark dispatcher supplies
separate logical resource scopes. All processes share the host CPU and storage.
The five files under runtime/ are byte copies of the retained E2 implementation.
The formal plan binds them and the benchmark code by SHA-256.

## Workload

There are 1, 4, 16, or 64 concurrently active candidates per run, for each of T,
B, and D. Every candidate receives the same 13-event lifecycle: admission;
primary pre-send authorization; primary send event; primary ACK; three low
reports; restore pre-send authorization; restore send event; restore ACK; three
recovery reports. The third low report naturally creates the restore proposal.
The fixture ACKs and reports are synthetic inputs, explicitly identified as such.
There is no operator-finish trigger. Original guards remain 3 s quiescence,
2.5 s header age, three consecutive reports, 0.6/0.8 baseline fractions, and a
20 s command deadline. Fixture event times are logical time: replay is not a
real-time radio experiment. All values and event times are in workload.json.

A readiness tick per worker completes before measurement. This includes process
startup/import and the initial empty-state snapshot, which are retained but
excluded from lifecycle costs. After every stage, the dispatcher waits for all
N responses before releasing the next synchronized burst (at most N events
in flight). Every shard therefore has an admitted, unfinished candidate before
any recovery completes. There is no sustained arrival-rate or saturation claim.
Payload JSON is encoded before a burst, and metrics are recorded in memory during
the run, then saved after measurement. Worker writes are never disabled.

Four formal repetitions use a Williams-balanced order of the four load levels:
1/4/64/16, 4/16/1/64, 16/64/4/1, and 64/1/16/4. The arm order rotates T/B/D at
successive load groups. The complete 48-run schedule is frozen. Every planned
attempt is retained, including failures; there are no performance-based retries
or outlier exclusions. A failed run prevents a verified-complete status.
Development pilots have separate plans and output directories and never enter
formal denominators. A fixed 0.25 s inter-run pause is outside measurement.

## Measurements and denominators

Each unchanged worker reports process CPU time and elapsed service time for the
policy transition (or authorization) plus full snapshot JSON encoding, file
write, flush, fsync, and atomic replacement. Input parsing and output encoding
are outside that worker timer. Snapshot durability here means the existing
file-fsync/replace path executes; no power-loss or filesystem crash test is made.

The dispatcher measures external dispatch wait from the common burst release
to the start of each pipe write. End-to-end processing latency runs from that
release to receipt of the corresponding worker response. The difference between
end-to-end latency, dispatch wait, and reported service is the **IPC/scheduling
residual**, including pipe I/O, worker input/output handling, OS scheduling, and
reader notification. It is not an independently observed internal worker queue.
The benchmark does not modify the worker to manufacture an entry timestamp.

The development pilot showed that the unchanged worker's process CPU timer on
this Windows host reports event increments in 15.625 ms steps. Its raw values,
zero fraction, total, and mean per event are retained without interpolation.
A zero CPU median is therefore not evidence of zero processing cost. Elapsed
service, dispatch wait, and end-to-end measurements use the high-resolution
performance counter and are the primary latency results. No conversion from
wall time to CPU time is made.

For CPU, service, dispatch wait, residual, and end-to-end latency, each run reports
the median and nearest-rank p95 across its 13N measured events. The presentation
summarizes the median of four run medians and median of four run p95s, and retains
the min/max across runs. This avoids treating events as independent replicate
runs. Lifecycle throughput is N divided by elapsed time from first admission
burst to the last recovery response. Event throughput is 13N over that same
window, including barriers and dispatcher work between stages. Process launch,
warmup, teardown, validation, and result-file writes are excluded. Final snapshot
bytes per candidate, total retained snapshot bytes, cumulative bytes written,
and exactly one snapshot fsync per measured event are separately reported.

## Required outcome checks

Each run must deliver and match all 13N event responses, generate two proposals
per candidate, authorize both, accept two fixture ACKs, observe low and restored
stages on the expected distinct three-report identities, emit exactly one
recovered terminal result, and persist a closed, noncancelled current owner with
the correct restore-to-primary edge and 100% checkpoint. The original admission
and observation guards are exercised. A post-completion authorization probe
(outside timing) must reject the same restore proposal. Final disk snapshots and
their hashes are retained. These are local state-machine checks, not evidence of
successful network transmissions or physical recovery.

## Interpretation

Results describe this host, Python runtime, OS, filesystem, finite burst load,
and explicit one-process-per-resource partition. They cannot establish RIC/RAN
latency, deployment-scale capacity, a shared-worker multi-resource implementation,
same-resource race safety, a record-format advantage, or a measured saturation
point. Background host load and filesystem caching are not experimentally fixed.
