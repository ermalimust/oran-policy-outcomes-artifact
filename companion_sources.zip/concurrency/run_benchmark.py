#!/usr/bin/env python3
"""Local per-resource sharding benchmark; unchanged workers, synthetic inputs."""
import argparse
import copy
import hashlib
import json
import os
import platform
import queue
import subprocess
import sys
import threading
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
NS = 1_000_000_000


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8')


def stamp():
    return datetime.now(timezone.utc).isoformat()


def bound_files():
    paths = [ROOT / name for name in ('run_benchmark.py', 'analyze_benchmark.py',
                                     'protocol.md', 'workload.json')]
    paths += sorted((ROOT / 'runtime').glob('*.py'))
    return {p.relative_to(ROOT).as_posix(): sha(p) for p in paths}


def freeze(path, kind):
    if path.exists():
        raise FileExistsError('Never overwrite a frozen plan')
    runs = []
    if kind == 'formal':
        loads = [[1, 4, 64, 16], [4, 16, 1, 64],
                 [16, 64, 4, 1], [64, 1, 16, 4]]
        for rep, sequence in enumerate(loads, 1):
            for position, n in enumerate(sequence):
                shift = ((rep - 1) * 4 + position) % 3
                arms = 'TBD'[shift:] + 'TBD'[:shift]
                for arm in arms:
                    runs.append(dict(run_id=f'f1-{len(runs)+1:02d}-{arm}-n{n}-r{rep}',
                                     arm=arm, active_candidates=n, repetition=rep))
    else:
        for arm in 'TBD':
            for n in (1, 4):
                runs.append(dict(run_id=f'p1-{len(runs)+1:02d}-{arm}-n{n}', arm=arm,
                                 active_candidates=n, repetition=1))
        runs.append(dict(run_id='p1-07-B-n64', arm='B', active_candidates=64, repetition=1))
    plan = dict(schema_version=1, experiment='local per-resource sharding benchmark',
                status='frozen_' + kind, attempt_kind=kind, created_utc=stamp(),
                runs=runs, planned_runs=len(runs), stage_timeout_s=30,
                inter_run_pause_s=0.25, runtime_and_artifact_sha256=bound_files(),
                interpretation='Synthetic local lifecycle processing only; one independent resource per original worker process; no RIC/RAN, same-resource concurrency, or saturation inference.')
    write_json(path, plan)
    print(json.dumps(dict(plan=path.name, sha256=sha(path), planned_runs=len(runs))))


class Child:
    def __init__(self, directory, arm, config):
        self.directory = directory
        directory.mkdir()
        self.config = config
        self.config_path = directory / 'config.json'
        self.journal = directory / 'worker_journal.json'
        write_json(self.config_path, config)
        self.stderr = (directory / 'worker.stderr').open('wb')
        self.spawn_start_ns = time.perf_counter_ns()
        self.process = subprocess.Popen(
            [sys.executable, '-B', str(ROOT / 'runtime/worker.py'), '--arm', arm,
             '--config', str(self.config_path), '--journal', str(self.journal)],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=self.stderr,
            text=True, encoding='utf-8', bufsize=1)
        self.spawn_return_ns = time.perf_counter_ns()
        self.received = queue.Queue()
        self.reader = threading.Thread(target=self.read, daemon=True)
        self.reader.start()

    def read(self):
        try:
            for line in self.process.stdout:
                received_ns = time.perf_counter_ns()
                self.received.put((received_ns, json.loads(line), None))
        except Exception:
            self.received.put((time.perf_counter_ns(), None, traceback.format_exc()))
        finally:
            self.received.put((time.perf_counter_ns(), None, 'worker_stdout_closed'))

    def stop(self):
        if self.process.poll() is None:
            try:
                self.process.stdin.close()
            except (BrokenPipeError, OSError):
                pass
        try:
            self.process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            self.process.kill()
            self.process.wait(timeout=5)
        self.reader.join(timeout=2)
        self.stderr.close()
        return self.process.returncode


def event_for(stage, i, run_id, config, workload, proposals):
    s = workload['stages'][stage]
    event_id = f'{run_id}-s{i:03d}-e{stage:02d}'
    role = s.get('role')
    kind = s['kind']
    if kind == 'operator_intent':
        body = copy.deepcopy(workload['intent'])
        body.update(policy_id=f'fixture-policy-{i}', candidate_id=f'fixture-candidate-{i}',
                    candidate_version=1, policy_revision=1, node_id=config['node_id'],
                    ue_id=config['ue_id'], baseline_kbit_s=config['baseline_kbit_s'])
    elif kind == 'authorize_send':
        body = copy.deepcopy(proposals[i][role])
    elif kind == 'wire_send':
        body = copy.deepcopy(proposals[i][role])
        body.update(node_id=config['node_id'], ue_id=0, sent_ns=round(s['seconds'] * NS),
                    requestor_id=1 if role == 'primary' else 2, instance_id=0, function_id=3,
                    fixture_only=True)
    elif kind == 'control_response':
        body = dict(node_id=config['node_id'], requestor_id=1 if role == 'primary' else 2,
                    instance_id=0, function_id=3, outcome='acknowledge',
                    raw_id=event_id + '-fixture-ack', fixture_only=True)
    elif kind == 'measurement':
        body = dict(node_id=config['node_id'], ue_id=0, subscription_id=config['subscription_id'],
                    metric=config['metric'], raw_id=event_id + '-fixture-kpm',
                    header_collection_ns=round(s['header_seconds'] * NS),
                    delivery_ns=round(s['seconds'] * NS), value_kbit_s=s['value_kbit_s'],
                    fixture_only=True)
    else:
        raise ValueError(kind)
    return dict(event_id=event_id, kind=kind, t_ns=round(s['seconds'] * NS), data=body)


def burst(children, events, label, timeout_s, records):
    encoded = [json.dumps(e, sort_keys=True) + '\n' for e in events]
    release = time.perf_counter_ns()
    pending = []
    for i, (child, event, payload) in enumerate(zip(children, events, encoded)):
        row = dict(shard=i, phase=label, event=event, burst_release_ns=release,
                   dispatch_start_ns=time.perf_counter_ns())
        records.append(row)  # Retain submissions even if a later write/response fails.
        child.process.stdin.write(payload)
        child.process.stdin.flush()
        row['dispatch_end_ns'] = time.perf_counter_ns()
        pending.append(row)
    deadline = time.perf_counter() + timeout_s
    for child, row in zip(children, pending):
        received, response, error = child.received.get(timeout=max(.001, deadline-time.perf_counter()))
        row['response_received_ns'] = received
        if error:
            row['error'] = error
            raise RuntimeError(error)
        row['response'] = response
        if response['input_event_id'] != row['event']['event_id']:
            raise AssertionError('Mismatched worker event response')
        service = response['cost']['wall_ns']
        row['dispatch_wait_ns'] = row['dispatch_start_ns'] - release
        row['end_to_end_ns'] = received - release
        row['ipc_scheduling_residual_ns'] = received - row['dispatch_start_ns'] - service
        if row['ipc_scheduling_residual_ns'] < 0:
            raise AssertionError('Negative measured residual')
    return pending


def state_view(arm, state):
    if arm == 'T':
        owner = state['contexts'][state['current']]
        primary = state['futures'][owner['primary_future']]
        restore = state['futures'][owner['restore_future']]
        return owner['closed'], owner['cancelled'], owner['call'], primary, restore
    if arm == 'B':
        owner = state['records'][state['head']]
        return owner['terminal'], owner['superseded'], owner['candidate'], owner['commands']['primary'], owner['commands']['restore']
    identity = state['desired']
    owner = state['phases'][identity]
    commands = []
    for role in ('primary', 'restore'):
        key = owner[role + '_id']
        command = dict(state['commands'][key], response=state['outcomes'][key],
                       evidence=state['observation_windows'][key]['evidence'],
                       parent_operation_id=state['parents'].get(key))
        commands.append(command)
    return owner['closed'], owner['cancelled'], state['intents'][identity], *commands


def validate(arm, children, rows, probes, n):
    assert len(rows) == 13 * n
    assert len(probes) == n
    snapshots = []
    for i, child in enumerate(children):
        observed = [r for r in rows if r['shard'] == i]
        assert len(observed) == 13
        outputs = [o for r in observed for o in r['response']['outputs']]
        by_kind = {}
        for output in outputs:
            by_kind.setdefault(output['kind'], []).append(output['data'])
        assert len(by_kind['command_proposed']) == 2
        assert [p['role'] for p in by_kind['command_proposed']] == ['primary', 'restore']
        assert by_kind['command_proposed'][1]['reason'] == 'low_observed'
        assert len(by_kind['send_authorization']) == 2
        assert all(p['authorized'] is True for p in by_kind['send_authorization'])
        assert len(by_kind['response_handled']) == 2
        assert all(p['accepted'] is True for p in by_kind['response_handled'])
        assert [p['stage'] for p in by_kind['stage_observed']] == ['low', 'restored']
        assert len(by_kind['terminal_decision']) == 1
        assert by_kind['terminal_decision'][0]['status'] == 'recovered'
        low = [r['event']['data']['raw_id'] for r in observed[4:7]]
        restored = [r['event']['data']['raw_id'] for r in observed[10:13]]
        assert by_kind['stage_observed'][0]['evidence_event_ids'] == low
        assert by_kind['stage_observed'][1]['evidence_event_ids'] == restored
        assert by_kind['terminal_decision'][0]['evidence_event_ids'] == restored
        assert probes[i]['response']['outputs'][0]['data']['authorized'] is False
        journal = json.loads(child.journal.read_text(encoding='utf-8'))
        assert journal['arm'] == arm and journal['episode_id'] == child.config['episode_id']
        closed, cancelled, candidate, primary, restore = state_view(arm, journal['state'])
        assert closed is True and cancelled is False
        assert candidate['node_id'] == child.config['node_id']
        assert primary['evidence'] == low and restore['evidence'] == restored
        assert restore['parent_operation_id'] == primary['operation_id']
        assert restore['requested_max_ratio'] == candidate['checkpoint']['max_ratio'] == 100
        assert restore['response']['outcome'] == 'acknowledge'
        snapshots.append(dict(shard=i, bytes=child.journal.stat().st_size, sha256=sha(child.journal)))
    # All admissions have completed before the second burst begins. No terminal
    # output occurs before the final stage, so the observed peak is exactly N.
    assert all(not any(o['kind'] == 'terminal_decision' for o in r['response']['outputs'])
               for r in rows if r['phase'] != 'stage12')
    assert sum(o['kind'] == 'terminal_decision' for r in rows for o in r['response']['outputs']) == n
    return dict(status='PASS', completed_candidates=n, peak_active_candidates=n,
                measured_events=13*n, fixture_acknowledgments=2*n, authorized_proposals=2*n,
                observed_stages=2*n, recovered_terminals=n,
                postcompletion_authorization_refused=n, snapshots=snapshots)


def run_one(run, directory, plan, workload):
    directory.mkdir()
    children, rows, warmup, probes = [], [], [], []
    result = dict(run, status='failed', started_utc=stamp())
    all_start = time.perf_counter_ns()
    n, arm = run['active_candidates'], run['arm']
    try:
        for i in range(n):
            config = dict(workload['config'], node_id=f'fixture-resource-{i:03d}',
                          episode_id=f"{run['run_id']}-shard-{i:03d}")
            children.append(Child(directory / f'shard_{i:03d}', arm, config))
        warm_events = [dict(event_id=f"{run['run_id']}-s{i:03d}-warmup", kind='tick', t_ns=0, data={})
                       for i in range(n)]
        burst(children, warm_events, 'warmup_excluded', plan['stage_timeout_s'], warmup)
        result['startup_and_readiness_wall_ns'] = time.perf_counter_ns() - all_start
        result['process_spawn_call_ns'] = [c.spawn_return_ns-c.spawn_start_ns for c in children]
        proposals = [{} for _ in children]
        for stage in range(13):
            events = [event_for(stage, i, run['run_id'], c.config, workload, proposals)
                      for i, c in enumerate(children)]
            batch = burst(children, events, f'stage{stage:02d}', plan['stage_timeout_s'], rows)
            for row in batch:
                for output in row['response']['outputs']:
                    if output['kind'] == 'command_proposed':
                        data = output['data']
                        if data['role'] in proposals[row['shard']]:
                            raise AssertionError('Duplicate proposal')
                        proposals[row['shard']][data['role']] = data
        result['measurement_start_ns'] = rows[0]['burst_release_ns']
        result['measurement_end_ns'] = max(r['response_received_ns'] for r in rows)
        result['lifecycle_wall_ns'] = result['measurement_end_ns'] - result['measurement_start_ns']
        probe_events = [dict(event_id=f"{run['run_id']}-s{i:03d}-postcompletion",
                             kind='authorize_send', t_ns=15*NS, data=proposals[i]['restore']) for i in range(n)]
        burst(children, probe_events, 'postcompletion_excluded', plan['stage_timeout_s'], probes)
        result['invariants'] = validate(arm, children, rows, probes, n)
        result['status'] = 'passed'
    except Exception:
        result['error'] = traceback.format_exc()
    finally:
        result['worker_exit_codes'] = [child.stop() for child in children]
        if any(code != 0 for code in result['worker_exit_codes']):
            result['status'] = 'failed'
        for name, records in [('events.jsonl', rows), ('warmup.jsonl', warmup), ('postcompletion.jsonl', probes)]:
            (directory / name).write_text(''.join(json.dumps(r, sort_keys=True)+'\n' for r in records), encoding='utf-8')
        result['finished_utc'] = stamp()
        result['measured_submissions'] = len(rows)
        result['measured_responses'] = sum('response' in r for r in rows)
        result['evidence_sha256'] = {p.relative_to(directory).as_posix(): sha(p)
                                     for p in sorted(directory.rglob('*')) if p.is_file()}
        write_json(directory / 'result.json', result)
    return result


def run_campaign(plan_path, output):
    if output.exists():
        raise FileExistsError('Never overwrite an attempt directory')
    plan = json.loads(plan_path.read_text(encoding='utf-8'))
    if bound_files() != plan['runtime_and_artifact_sha256']:
        raise ValueError('Frozen artifact/runtime hashes changed')
    output.mkdir(parents=True)
    write_json(output / 'plan.json', plan)
    environment = dict(python=sys.version, platform=platform.platform(), processor=platform.processor(),
                       architecture=platform.machine(), logical_cpus=os.cpu_count(),
                       perf_counter=time.get_clock_info('perf_counter').__dict__,
                       process_time=time.get_clock_info('process_time').__dict__,
                       note='No CPU affinity, exclusive host reservation, or cache flushing; startup excluded and separately retained.')
    write_json(output / 'environment.json', environment)
    workload = json.loads((ROOT / 'workload.json').read_text(encoding='utf-8'))
    manifest = dict(schema_version=1, attempt_kind=plan['attempt_kind'], plan_sha256=sha(plan_path),
                    planned_runs=plan['planned_runs'], started_utc=stamp(), attempts=[])
    for run in plan['runs']:
        result = run_one(run, output / run['run_id'], plan, workload)
        manifest['attempts'].append(dict(run, status=result['status'], result_sha256=sha(output/run['run_id']/'result.json')))
        write_json(output / 'manifest.json', manifest)
        print(json.dumps(dict(run_id=run['run_id'], status=result['status'],
                              completed=len(manifest['attempts']), planned=plan['planned_runs'])), flush=True)
        time.sleep(plan['inter_run_pause_s'])
    manifest['finished_utc'] = stamp()
    manifest['status'] = 'completed' if all(x['status'] == 'passed' for x in manifest['attempts']) else 'completed_with_failures'
    write_json(output / 'manifest.json', manifest)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    p = sub.add_parser('freeze')
    p.add_argument('--plan', type=Path, required=True)
    p.add_argument('--kind', choices=['pilot', 'formal'], required=True)
    p = sub.add_parser('run')
    p.add_argument('--plan', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.command == 'freeze':
        freeze(args.plan, args.kind)
    else:
        run_campaign(args.plan, args.output)


if __name__ == '__main__':
    main()
