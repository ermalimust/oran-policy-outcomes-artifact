#!/usr/bin/env python3
"""Recompute metrics and verify every planned local-sharding run, without filtering."""
import argparse
import csv
import hashlib
import json
import math
import statistics
from pathlib import Path


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def jsonl(path):
    return [json.loads(line) for line in Path(path).read_text(encoding='utf-8').splitlines()]


def p95(values):
    return sorted(values)[math.ceil(.95*len(values))-1]


def write_csv(path, rows):
    with Path(path).open('w', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def analyze(campaign, output):
    if output.exists():
        raise FileExistsError('Never overwrite an analysis directory')
    output.mkdir(parents=True)
    manifest = json.loads((campaign/'manifest.json').read_text(encoding='utf-8'))
    plan = json.loads((campaign/'plan.json').read_text(encoding='utf-8'))
    expected = [r['run_id'] for r in plan['runs']]
    attempts = [r['run_id'] for r in manifest['attempts']]
    issues = []
    if attempts != expected:
        issues.append('Planned and attempted run sequence differs')
    run_rows, invariant_totals = [], dict(completed_candidates=0, measured_events=0, recovered_terminals=0,
                                         authorized_proposals=0, postcompletion_authorization_refused=0)
    inputs = {'manifest.json':sha(campaign/'manifest.json'), 'plan.json':sha(campaign/'plan.json'),
              'environment.json':sha(campaign/'environment.json')}
    for attempt in manifest['attempts']:
        directory = campaign/attempt['run_id']
        result = json.loads((directory/'result.json').read_text(encoding='utf-8'))
        result_hash = sha(directory/'result.json')
        inputs[f"{attempt['run_id']}/result.json"] = result_hash
        if attempt['result_sha256'] != result_hash:
            issues.append(f"{attempt['run_id']}: result hash differs")
        for relative, expected_hash in result['evidence_sha256'].items():
            if sha(directory/relative) != expected_hash:
                issues.append(f"{attempt['run_id']}/{relative}: evidence hash differs")
        row = dict(run_id=attempt['run_id'], arm=attempt['arm'], active_candidates=attempt['active_candidates'],
                   repetition=attempt['repetition'], status=result['status'])
        if result['status'] != 'passed':
            issues.append(attempt['run_id']+': failed attempt retained')
            run_rows.append(row)
            continue
        events = jsonl(directory/'events.jsonl')
        n = attempt['active_candidates']
        assert len(events) == 13*n
        assert len({e['event']['event_id'] for e in events}) == 13*n
        for record in events:
            assert record['response']['input_event_id'] == record['event']['event_id']
            assert record['dispatch_wait_ns'] == record['dispatch_start_ns']-record['burst_release_ns']
            assert record['end_to_end_ns'] == record['response_received_ns']-record['burst_release_ns']
            assert record['ipc_scheduling_residual_ns'] == record['end_to_end_ns']-record['dispatch_wait_ns']-record['response']['cost']['wall_ns']
            assert record['response']['cost']['fsync_calls'] == 1
        for key, field in [('cpu','cpu_ns'), ('service','wall_ns')]:
            values = [e['response']['cost'][field]/1e6 for e in events]
            row[key+'_median_ms'] = statistics.median(values)
            row[key+'_p95_ms'] = p95(values)
        for key, field in [('dispatch_wait','dispatch_wait_ns'), ('ipc_scheduling_residual','ipc_scheduling_residual_ns'),
                           ('end_to_end','end_to_end_ns')]:
            values = [e[field]/1e6 for e in events]
            row[key+'_median_ms'] = statistics.median(values)
            row[key+'_p95_ms'] = p95(values)
        elapsed = (max(e['response_received_ns'] for e in events)-events[0]['burst_release_ns'])/1e9
        assert round(elapsed*1e9) == result['lifecycle_wall_ns']
        row.update(lifecycle_wall_s=elapsed, candidates_per_s=n/elapsed, events_per_s=len(events)/elapsed,
                   startup_readiness_s=result['startup_and_readiness_wall_ns']/1e9,
                   measured_events=len(events), completed_candidates=result['invariants']['completed_candidates'],
                   peak_active_candidates=result['invariants']['peak_active_candidates'],
                   snapshot_median_bytes=statistics.median(s['bytes'] for s in result['invariants']['snapshots']),
                   snapshot_total_bytes=sum(s['bytes'] for s in result['invariants']['snapshots']),
                   snapshot_cumulative_bytes_written=sum(e['response']['cost']['journal_bytes_written'] for e in events),
                   fsync_calls=sum(e['response']['cost']['fsync_calls'] for e in events),
                   cpu_total_ms=sum(e['response']['cost']['cpu_ns'] for e in events)/1e6,
                   cpu_mean_ms=statistics.mean(e['response']['cost']['cpu_ns'] for e in events)/1e6,
                   cpu_zero_fraction=sum(e['response']['cost']['cpu_ns']==0 for e in events)/len(events))
        for s in result['invariants']['snapshots']:
            path = directory/f"shard_{s['shard']:03d}"/'worker_journal.json'
            assert sha(path) == s['sha256'] and path.stat().st_size == s['bytes']
        for key in invariant_totals:
            invariant_totals[key] += result['invariants'][key]
        run_rows.append(row)
    fields = list(dict.fromkeys(k for row in run_rows for k in row))
    with (output/'runs.csv').open('w',newline='',encoding='utf-8') as handle:
        writer=csv.DictWriter(handle,fieldnames=fields);writer.writeheader();writer.writerows(run_rows)
    aggregates = []
    for n in (1,4,16,64):
        for arm in 'TBD':
            planned = [r for r in plan['runs'] if r['active_candidates']==n and r['arm']==arm]
            rows = [r for r in run_rows if r['active_candidates']==n and r['arm']==arm]
            passed = [r for r in rows if r['status']=='passed']
            agg = dict(arm=arm, active_candidates=n, planned_runs=len(planned), attempted_runs=len(rows),
                       passed_runs=len(passed), failed_or_missing_runs=len(planned)-len(passed))
            # A cell with a failure remains explicitly incomplete. No successful-
            # only performance estimate is substituted for that planned cell.
            if passed and len(passed)==len(planned):
                for key in fields:
                    if key in ('run_id','arm','active_candidates','repetition','status'):
                        continue
                    values = [r[key] for r in passed]
                    agg[key] = statistics.median(values)
                    agg[key+'_run_min'] = min(values)
                    agg[key+'_run_max'] = max(values)
            aggregates.append(agg)
    aggfields = list(dict.fromkeys(k for row in aggregates for k in row))
    with (output/'aggregate.csv').open('w',newline='',encoding='utf-8') as handle:
        writer=csv.DictWriter(handle,fieldnames=aggfields);writer.writeheader();writer.writerows(aggregates)
    complete = not issues and len(attempts)==plan['planned_runs']
    summary = dict(schema_version=1, status=('verified_formal' if plan['attempt_kind']=='formal' else 'verified_pilot') if complete else 'incomplete',
                   experiment='local per-resource sharding benchmark', attempt_kind=plan['attempt_kind'],
                   planned_runs=plan['planned_runs'], attempted_runs=len(attempts),
                   passed_runs=sum(r['status']=='passed' for r in run_rows), issues=issues,
                   totals=invariant_totals, aggregate_rows=aggregates,
                   method='Median of run medians and median of run nearest-rank p95s; separate run minima/maxima retained.',
                   cpu_resolution_note='Original worker uses process_time_ns. On Windows this may produce quantized individual-event CPU times; zeros are retained, not imputed.',
                   scope='Unchanged original worker per independent logical resource. Synthetic event fixtures and logical times; local CPU/storage contention only. Internal worker queue is not isolated from IPC/scheduling residual.',
                   input_sha256=inputs)
    (output/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(json.dumps({k:summary[k] for k in ('status','planned_runs','attempted_runs','passed_runs','totals','issues')}))


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--campaign',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();analyze(args.campaign,args.output)
