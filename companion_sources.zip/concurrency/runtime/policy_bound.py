"""Explicit immutable candidate/command/checkpoint aggregate implementation."""
from common import (admission_valid, candidate_key, operation, response_matches, observe,
                    has_confirmation, proposed, terminal, stage_event, response_event, finish_matches)


class BoundPolicy:
    def __init__(self, config, state=None):
        self.config = config
        self.state = state or {'head':None, 'records':{}, 'latest_wire_ns':0}

    def on_event(self, event):
        outputs = []
        kind, body, now = event['kind'], event['data'], event['t_ns']
        if kind in ('operator_intent', 'operator_finish'):
            revision = body.get('policy_revision', 0)
            if revision <= self.state.get('last_policy_revision', 0):
                return [{'kind':'intent_ignored','data':{'reason':'nonmonotonic_policy_revision'}}]
            self.state['last_policy_revision'] = revision
        if kind == 'operator_intent':
            previous = self.state['records'].get(self.state['head'])
            if previous and body['candidate_version'] <= previous['candidate']['candidate_version']:
                return [{'kind':'intent_ignored','data':{'reason':'nonmonotonic_version'}}]
            if previous:
                previous['superseded'] = True
                if not previous['terminal']:
                    outputs.append(terminal(previous['candidate'], 'superseded', reason='new_operator_version'))
            key = candidate_key(body)
            record = {'candidate':dict(body), 'commands':{}, 'superseded':False,
                      'terminal':False, 'operator_finish':False, 'deadline_notified':False}
            self.state['records'][key] = record
            self.state['head'] = key
            if admission_valid(body, now, self.config):
                command = operation(body, 'primary')
                record['commands']['primary'] = command
                outputs.append(proposed(command, 'authorized_primary', []))
            else:
                record['terminal'] = True
                outputs.append(terminal(body, 'failed', reason='admission_rejected'))
        elif kind == 'operator_revoke':
            record = self.state['records'].get(self.state['head'])
            if record and record['candidate']['policy_id']==body['policy_id']:
                record['superseded'] = True
                if not record['terminal']:
                    outputs.append(terminal(record['candidate'],'cancelled',reason='policy_revoked'))
        elif kind == 'wire_send':
            self.state['latest_wire_ns'] = max(self.state['latest_wire_ns'], body['sent_ns'])
            for record in self.state['records'].values():
                for command in record['commands'].values():
                    if command['operation_id'] == body['operation_id']:
                        command['wire'] = dict(body)
        elif kind == 'control_response':
            found = [c for r in self.state['records'].values() for c in r['commands'].values()
                     if response_matches(c, body)]
            if len(found) != 1:
                outputs.append(response_event(None, body, False, 'unknown_transaction'))
            else:
                command = found[0]
                duplicate = command['response'] is not None
                if not duplicate:
                    command['response'] = dict(body)
                outputs.append(response_event(command, body, not duplicate, 'duplicate' if duplicate else 'exact_command_child'))
        elif kind == 'operator_finish':
            head = self.state['records'].get(self.state['head'])
            if head and finish_matches(head['candidate'], body):
                head['operator_finish'] = True
        elif kind == 'measurement':
            head = self.state['records'].get(self.state['head'])
            if head and not head['terminal'] and not head['superseded']:
                command = head['commands'].get('restore') or head['commands'].get('primary')
                if command:
                    observe(command, body, self.config, self.state['latest_wire_ns'])
        self._transition_head(now, outputs)
        return outputs

    def _transition_head(self, now, outputs):
        record = self.state['records'].get(self.state['head'])
        if record is None or record['terminal'] or record['superseded']:
            return
        candidate = record['candidate']
        commands = record['commands']
        release = commands.get('primary')
        restore = commands.get('restore')
        if release is None:
            return
        if not admission_valid(candidate, now, self.config):
            record['terminal'] = True
            outputs.append(terminal(candidate, 'unresolved', restore or release, 'authority_expired'))
            return
        if restore is not None:
            # The explicit edge is checked, rather than inferred from the latest ACK.
            if restore['parent_operation_id'] != release['operation_id']:
                record['terminal'] = True
                outputs.append(terminal(candidate, 'failed', restore, 'broken_parent_edge'))
                return
            if restore['response'] and restore['response']['outcome']=='failure':
                record['terminal'] = True
                outputs.append(terminal(candidate, 'failed', restore, 'actual_restore_failure'))
            elif has_confirmation(restore, self.config):
                outputs.append(stage_event(candidate, restore, self.config))
                record['terminal'] = True
                outputs.append(terminal(candidate, 'recovered', restore, 'confirmed_current_workflow', self.config))
            elif restore['wire'] and now-restore['wire']['sent_ns'] > self.config['command_timeout_s']*1e9 and not record['deadline_notified']:
                record['deadline_notified'] = True
                outputs.append(terminal(candidate, 'unresolved', restore, 'restore_deadline'))
            return
        if has_confirmation(release, self.config) and not release['observed']:
            release['observed'] = True
            outputs.append(stage_event(candidate, release, self.config))
        reason = None
        allowed = candidate['restore_on']
        if record['operator_finish'] and 'operator_finish' in allowed:
            reason = 'operator_finish'
        elif release['response'] and release['response']['outcome']=='failure' and 'control_failure' in allowed:
            reason = 'control_failure'
        elif release['observed'] and 'low_observed' in allowed:
            reason = 'low_observed'
        elif release['wire'] and now-release['wire']['sent_ns'] > self.config['command_timeout_s']*1e9 and 'timeout' in allowed:
            reason = 'timeout'
        if reason is not None:
            restore = operation(candidate, 'restore', release['operation_id'])
            commands['restore'] = restore
            outputs.append(proposed(restore, reason, release['evidence']))

    def authorize_send(self, proposal, now):
        record = self.state['records'].get(self.state['head'])
        if not record or record['terminal'] or record['superseded']:
            return False
        candidate = record['candidate']
        command = record['commands'].get(proposal['role'])
        if not command or command['operation_id'] != proposal['operation_id']:
            return False
        if proposal['role']=='restore' and command['parent_operation_id'] != record['commands']['primary']['operation_id']:
            return False
        return (all(command[k] == candidate[k] for k in ('policy_id','candidate_id','candidate_version'))
                and command['requested_max_ratio'] == proposal['requested_max_ratio']
                and command['checkpoint_version'] == candidate['checkpoint']['version']
                and admission_valid(candidate, now, self.config))
