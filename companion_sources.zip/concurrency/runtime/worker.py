#!/usr/bin/env python3
"""Separate crashable JSON-lines policy process; no RIC/RAN response simulation."""
import argparse
import json
import sys
import time
from pathlib import Path
from common import atomic_json
from policy_transaction import TransactionPolicy
from policy_bound import BoundPolicy
from policy_distributed import DistributedPolicy

POLICIES = {'T':TransactionPolicy, 'B':BoundPolicy, 'D':DistributedPolicy}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--arm', choices=sorted(POLICIES), required=True)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--journal', type=Path, required=True)
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    state = None
    if args.journal.exists():
        journal = json.loads(args.journal.read_text())
        if journal['arm'] != args.arm or journal['episode_id'] != config['episode_id']:
            raise ValueError('Journal arm/episode mismatch')
        state = journal['state']
    policy = POLICIES[args.arm](config, state)
    for line in sys.stdin:
        event = json.loads(line)
        started = time.perf_counter_ns()
        cpu_started = time.process_time_ns()
        if event['kind'] == 'authorize_send':
            outputs = [{'kind':'send_authorization', 'data':{
                'operation_id':event['data']['operation_id'],
                'authorized':policy.authorize_send(event['data'], event['t_ns'])}}]
        else:
            outputs = policy.on_event(event)
        bytes_written = atomic_json(args.journal, {
            'arm':args.arm, 'episode_id':config['episode_id'], 'state':policy.state})
        output = {'input_event_id':event['event_id'], 'outputs':outputs,
                  'cost':{'cpu_ns':time.process_time_ns()-cpu_started,
                          'wall_ns':time.perf_counter_ns()-started,
                          'journal_bytes_written':bytes_written,'fsync_calls':1}}
        print(json.dumps(output, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
