"""Strong normalized-table composition with the same substantive predicates.

This implementation never calls the bound policy's transition function.
"""
from common import (admission_valid, candidate_key, operation, response_matches, observe,
                    has_confirmation, proposed, terminal, stage_event, response_event, finish_matches)


class DistributedPolicy:
    def __init__(self, config, state=None):
        self.config = config
        self.state = state or {'desired':None, 'intents':{}, 'phases':{}, 'commands':{},
                               'outcomes':{}, 'observation_windows':{}, 'parents':{}, 'latest_wire_ns':0}

    def _view(self, identity):
        if identity is None:
            return None
        row = dict(self.state['commands'][identity])
        row['response'] = self.state['outcomes'].get(identity)
        window = self.state['observation_windows'][identity]
        row['evidence'] = list(window['evidence'])
        row['last_header_ns'] = window['last_header_ns']
        row['parent_operation_id'] = self.state['parents'].get(identity)
        return row

    def _insert(self, intent, role, parent=None):
        op = operation(intent, role, parent)
        identity = op['operation_id']
        self.state['commands'][identity] = {k:v for k,v in op.items()
                                            if k not in ('response','evidence','last_header_ns','parent_operation_id')}
        self.state['observation_windows'][identity] = {'evidence':[], 'last_header_ns':-1}
        if parent is not None:
            self.state['parents'][identity] = parent
        return op

    def on_event(self, event):
        kind, body, now = event['kind'], event['data'], event['t_ns']
        result = []
        if kind in ('operator_intent', 'operator_finish'):
            revision = body.get('policy_revision', 0)
            if revision <= self.state.get('last_policy_revision', 0):
                return [{'kind':'intent_ignored','data':{'reason':'nonmonotonic_policy_revision'}}]
            self.state['last_policy_revision'] = revision
        if kind == 'operator_intent':
            previous = self.state['desired']
            if previous and body['candidate_version'] <= self.state['intents'][previous]['candidate_version']:
                return [{'kind':'intent_ignored','data':{'reason':'nonmonotonic_version'}}]
            if previous is not None:
                phase = self.state['phases'][previous]
                phase['cancelled'] = True
                if not phase['closed']:
                    result.append(terminal(self.state['intents'][previous], 'superseded', reason='new_operator_version'))
            identity = candidate_key(body)
            self.state['intents'][identity] = dict(body)
            self.state['desired'] = identity
            phase = {'primary_id':None, 'restore_id':None, 'cancelled':False, 'closed':False,
                     'finish_authorized':False, 'deadline_reported':False}
            self.state['phases'][identity] = phase
            if admission_valid(body, now, self.config):
                command = self._insert(body, 'primary')
                phase['primary_id'] = command['operation_id']
                result.append(proposed(command, 'authorized_primary', []))
            else:
                phase['closed'] = True
                result.append(terminal(body, 'failed', reason='admission_rejected'))
        elif kind == 'operator_revoke':
            desired = self.state['desired']
            if desired and self.state['intents'][desired]['policy_id']==body['policy_id']:
                self.state['phases'][desired]['cancelled'] = True
                if not self.state['phases'][desired]['closed']:
                    result.append(terminal(self.state['intents'][desired],'cancelled',reason='policy_revoked'))
        elif kind == 'wire_send':
            self.state['latest_wire_ns'] = max(self.state['latest_wire_ns'], body['sent_ns'])
            row = self.state['commands'].get(body['operation_id'])
            if row is not None:
                row['wire'] = dict(body)
        elif kind == 'control_response':
            identities = [key for key in self.state['commands'] if response_matches(self._view(key), body)]
            if len(identities) != 1:
                result.append(response_event(None, body, False, 'unknown_transaction'))
            else:
                identity = identities[0]
                duplicate = identity in self.state['outcomes']
                if not duplicate:
                    self.state['outcomes'][identity] = dict(body)
                result.append(response_event(self._view(identity), body, not duplicate,
                                             'duplicate' if duplicate else 'transaction_origin_join'))
        elif kind == 'operator_finish':
            desired = self.state['desired']
            if desired and finish_matches(self.state['intents'][desired], body):
                self.state['phases'][desired]['finish_authorized'] = True
        elif kind == 'measurement':
            desired = self.state['desired']
            if desired:
                phase = self.state['phases'][desired]
                identity = phase['restore_id'] or phase['primary_id']
                if identity and not phase['cancelled'] and not phase['closed']:
                    command = self._view(identity)
                    observe(command, body, self.config, self.state['latest_wire_ns'])
                    self.state['observation_windows'][identity] = {
                        'evidence':list(command['evidence']), 'last_header_ns':command['last_header_ns']}
        self._join_and_advance(now, result)
        return result

    def _join_and_advance(self, now, result):
        desired = self.state['desired']
        if desired is None:
            return
        phase = self.state['phases'][desired]
        intent = self.state['intents'][desired]
        if phase['cancelled'] or phase['closed']:
            return
        primary = self._view(phase['primary_id'])
        restore = self._view(phase['restore_id'])
        if primary is None:
            return
        if not admission_valid(intent, now, self.config):
            phase['closed'] = True
            result.append(terminal(intent, 'unresolved', restore or primary, 'authority_expired'))
            return
        if restore is not None:
            if self.state['parents'].get(restore['operation_id']) != primary['operation_id']:
                phase['closed'] = True
                result.append(terminal(intent, 'failed', restore, 'broken_parent_edge'))
                return
            outcome = self.state['outcomes'].get(restore['operation_id'])
            if outcome and outcome['outcome']=='failure':
                phase['closed'] = True
                result.append(terminal(intent, 'failed', restore, 'actual_restore_failure'))
            elif has_confirmation(restore, self.config):
                result.append(stage_event(intent, restore, self.config))
                phase['closed'] = True
                result.append(terminal(intent, 'recovered', restore, 'confirmed_current_workflow', self.config))
            elif restore['wire'] and now-restore['wire']['sent_ns'] > self.config['command_timeout_s']*1e9 and not phase['deadline_reported']:
                phase['deadline_reported'] = True
                result.append(terminal(intent, 'unresolved', restore, 'restore_deadline'))
            return
        if has_confirmation(primary, self.config) and not primary['observed']:
            self.state['commands'][primary['operation_id']]['observed'] = True
            primary['observed'] = True
            result.append(stage_event(intent, primary, self.config))
        trigger = None
        allowed = intent['restore_on']
        if phase['finish_authorized'] and 'operator_finish' in allowed:
            trigger = 'operator_finish'
        elif primary['response'] and primary['response']['outcome']=='failure' and 'control_failure' in allowed:
            trigger = 'control_failure'
        elif primary['observed'] and 'low_observed' in allowed:
            trigger = 'low_observed'
        elif primary['wire'] and now-primary['wire']['sent_ns'] > self.config['command_timeout_s']*1e9 and 'timeout' in allowed:
            trigger = 'timeout'
        if trigger:
            command = self._insert(intent, 'restore', primary['operation_id'])
            phase['restore_id'] = command['operation_id']
            result.append(proposed(command, trigger, primary['evidence']))

    def authorize_send(self, proposal, now):
        desired = self.state['desired']
        if desired is None:
            return False
        intent, phase = self.state['intents'][desired], self.state['phases'][desired]
        row = self.state['commands'].get(proposal['operation_id'])
        if row is None or phase['closed'] or phase['cancelled']:
            return False
        if proposal['role']=='restore' and self.state['parents'].get(row['operation_id']) != phase['primary_id']:
            return False
        return (all(row[k]==intent[k] for k in ('policy_id','candidate_id','candidate_version'))
                and row['requested_max_ratio']==proposal['requested_max_ratio']
                and row['checkpoint_version']==intent['checkpoint']['version']
                and admission_valid(intent, now, self.config))
