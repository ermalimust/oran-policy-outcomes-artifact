"""Shared transport/storage primitives and explicitly common leaf predicates.

No oracle truth or policy-specific transition lives here. Python 3.8 compatible.
"""
import hashlib
import json
import math
import os
import time
from pathlib import Path


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode()
    temporary = path.with_name(path.name + '.tmp')
    with temporary.open('wb') as handle:
        handle.write(encoded)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(str(temporary), str(path))
    return len(encoded)


class RawSpool:
    def __init__(self, directory):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)

    def put(self, payload):
        value = bytes(payload)
        checksum = hashlib.sha256(value).hexdigest()
        path = self.directory / (checksum + '.bin')
        if not path.exists():
            with path.open('xb') as handle:
                handle.write(value)
                handle.flush()
                os.fsync(handle.fileno())
        return checksum, str(path)

    def get(self, checksum):
        value = (self.directory / (checksum + '.bin')).read_bytes()
        if hashlib.sha256(value).hexdigest() != checksum:
            raise ValueError('Raw payload hash mismatch')
        return value


class RequestAllocator:
    """Never reuse a 16-bit ID during the retained local campaign epoch."""
    def __init__(self, path):
        self.path = Path(path)
        self.counter = json.loads(self.path.read_text())['last_requestor_id'] if self.path.exists() else 1000

    def allocate(self):
        if self.counter >= 65535:
            raise RuntimeError('Request ID space exhausted; do not silently wrap')
        self.counter += 1
        atomic_json(self.path, {'last_requestor_id': self.counter})
        return self.counter


def patch_requestor_id(payload, requestor_id):
    """Patch only the documented RICrequestID IE in the upstream sample encoder.

    That sample encodes requestor IDs modulo 255. The complete actual E2 bytes
    are retained and independently decoded; this never patches a response.
    """
    value = bytearray(payload)
    if value[:3] != bytes([0, 4, 0]):
        raise ValueError('Unsupported control-request envelope')
    marker = bytes.fromhex('001d000500')
    indices = [i for i in range(4, min(len(value)-8, 32)) if value[i:i+5] == marker]
    if len(indices) != 1 or not 0 <= requestor_id <= 65535:
        raise ValueError('Request identity IE not uniquely recognized')
    start = indices[0] + 5
    value[start:start+2] = requestor_id.to_bytes(2, 'big')
    return bytes(value)


def candidate_key(intent):
    return '{}:{}:{}'.format(intent['policy_id'], intent['candidate_id'], intent['candidate_version'])


def finish_matches(intent, event):
    if not all(intent[k] == event[k] for k in ('policy_id','candidate_id','candidate_version')):
        return False
    original, update = intent.get('source_policy_payload'), event.get('source_policy_payload')
    if original is not None or update is not None:
        if not isinstance(original, dict) or not isinstance(update, dict):
            return False
        ignored = ('phase', 'policy_revision')
        return {k:v for k,v in original.items() if k not in ignored} == {k:v for k,v in update.items() if k not in ignored}
    return True


def operation(intent, role, parent=None):
    identity = candidate_key(intent) + ':' + role
    return {'operation_id': identity, 'policy_id': intent['policy_id'],
            'candidate_id': intent['candidate_id'], 'candidate_version': intent['candidate_version'],
            'role': role, 'parent_operation_id': parent,
            'requested_max_ratio': intent['target_max_ratio'] if role == 'primary' else intent['checkpoint']['max_ratio'],
            'checkpoint_id': intent['checkpoint']['id'], 'checkpoint_version': intent['checkpoint']['version'],
            'wire': None, 'response': None, 'evidence': [], 'last_header_ns': -1,
            'timed_out': False, 'observed': False}


def admission_valid(intent, now_ns, config=None):
    return (intent['effective_ns'] <= now_ns < intent['expires_ns']
            and (config is None or all(intent[k] == config[k] for k in ('node_id','ue_id')))
            and intent['min_ratio'] == 1 and intent['dedicated_ratio'] == 100
            and intent['checkpoint']['available']
            and 0 <= intent['min_ratio'] <= intent['target_max_ratio'] <= intent['delegated_max_ratio'] <= 100
            and 0 <= intent['min_ratio'] <= intent['checkpoint']['max_ratio'] <= intent['delegated_max_ratio'])


def response_matches(op, response):
    wire = op.get('wire')
    return bool(wire and all(wire[field] == response[field]
                            for field in ('node_id', 'requestor_id', 'instance_id', 'function_id')))


def observe(op, measurement, config, latest_wire_ns):
    """Common observation filter; does not decide lifecycle ownership/closure."""
    wire = op.get('wire')
    if not wire:
        return False
    value = measurement.get('value_kbit_s')
    header = measurement.get('header_collection_ns')
    if not isinstance(value, (float, int)) or not math.isfinite(value) or header is None:
        return False
    if any(measurement.get(k) != config[k] for k in ('node_id', 'ue_id', 'subscription_id', 'metric')):
        return False
    if latest_wire_ns != wire['sent_ns'] or header <= op['last_header_ns']:
        return False
    if header < latest_wire_ns + int(config['quiescence_s']*1e9):
        return False
    age = measurement['delivery_ns'] - header
    if age < 0 or age > config['max_header_age_s']*1e9:
        return False
    op['last_header_ns'] = header
    fraction = config['low_fraction'] if op['role'] == 'primary' else config['recovery_fraction']
    threshold = config['baseline_kbit_s'] * fraction
    qualifies = value <= threshold if op['role'] == 'primary' else value >= threshold
    if qualifies:
        op['evidence'].append(measurement['raw_id'])
        op['evidence'] = op['evidence'][-config['confirmations']:]
    else:
        op['evidence'] = []
    return qualifies


def has_confirmation(op, config):
    return bool(op.get('response') and op['response']['outcome'] == 'acknowledge'
                and len(op['evidence']) >= config['confirmations'])


def proposed(op, reason, evidence):
    keys = ('operation_id','policy_id','candidate_id','candidate_version','role',
            'parent_operation_id','requested_max_ratio','checkpoint_id','checkpoint_version')
    return {'kind': 'command_proposed', 'data': dict({k:op[k] for k in keys}, reason=reason,
                                                   evidence_event_ids=list(evidence))}


def terminal(intent, status, op=None, reason=None, config=None):
    return {'kind':'terminal_decision', 'data': {
        'policy_id':intent['policy_id'], 'candidate_id':intent['candidate_id'],
        'candidate_version':intent['candidate_version'], 'status':status, 'reason':reason,
        'operation_id':op['operation_id'] if op else None,
        'response_raw_id':op['response']['raw_id'] if op and op.get('response') else None,
        'evidence_event_ids':list(op['evidence']) if op else [],
        'window_assurance':config.get('window_assurance') if config else None}}


def stage_event(intent, op, config):
    return {'kind':'stage_observed', 'data': {
        'policy_id':intent['policy_id'], 'candidate_id':intent['candidate_id'],
        'candidate_version':intent['candidate_version'], 'operation_id':op['operation_id'],
        'stage':'low' if op['role']=='primary' else 'restored',
        'evidence_event_ids':list(op['evidence']), 'reference_kbit_s':config['baseline_kbit_s'],
        'window_assurance':config['window_assurance']}}


def response_event(op, response, accepted, reason):
    return {'kind':'response_handled', 'data': {
        'raw_id':response['raw_id'], 'operation_id':op['operation_id'] if op else None,
        'policy_id':op['policy_id'] if op else None,
        'candidate_id':op['candidate_id'] if op else None,
        'candidate_version':op['candidate_version'] if op else None,
        'accepted':accepted, 'reason':reason}}
