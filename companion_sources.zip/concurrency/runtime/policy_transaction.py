"""Competent experimental transaction/future workflow, with native persistence.

It retains caller context and cancellation; it is not a weakened ACK-only arm.
"""
from common import (admission_valid, candidate_key, operation, response_matches, observe,
                    has_confirmation, proposed, terminal, stage_event, response_event, finish_matches)


class TransactionPolicy:
    def __init__(self, config, state=None):
        self.config = config
        self.state = state or {'current':None, 'contexts':{}, 'futures':{}, 'latest_wire_ns':0}

    def _future(self, context, role):
        key = context.get(role + '_future')
        return self.state['futures'].get(key)

    def _issue(self, context, role, reason, evidence):
        parent = context.get('primary_future') if role == 'restore' else None
        op = operation(context['call'], role, parent)
        self.state['futures'][op['operation_id']] = op
        context[role + '_future'] = op['operation_id']
        return proposed(op, reason, evidence)

    def on_event(self, event):
        kind, data, now = event['kind'], event['data'], event['t_ns']
        outputs = []
        if kind in ('operator_intent', 'operator_finish'):
            revision = data.get('policy_revision', 0)
            if revision <= self.state.get('last_policy_revision', 0):
                return [{'kind':'intent_ignored','data':{'reason':'nonmonotonic_policy_revision'}}]
            self.state['last_policy_revision'] = revision
        if kind == 'operator_intent':
            old = self.state['contexts'].get(self.state['current'])
            if old and data['candidate_version'] <= old['call']['candidate_version']:
                return [{'kind':'intent_ignored','data':{'reason':'nonmonotonic_version'}}]
            if old:
                old['cancelled'] = True
                if not old['closed']:
                    outputs.append(terminal(old['call'], 'superseded', reason='new_operator_version'))
            key = candidate_key(data)
            context = {'call':dict(data), 'cancelled':False, 'closed':False,
                       'finish':False, 'timeout_reported':False}
            self.state['contexts'][key] = context
            self.state['current'] = key
            if admission_valid(data, now, self.config):
                outputs.append(self._issue(context, 'primary', 'authorized_primary', []))
            else:
                context['closed'] = True
                outputs.append(terminal(data, 'failed', reason='admission_rejected'))
        elif kind == 'operator_revoke':
            context = self.state['contexts'].get(self.state['current'])
            if context and context['call']['policy_id']==data['policy_id']:
                context['cancelled'] = True
                if not context['closed']:
                    outputs.append(terminal(context['call'],'cancelled',reason='policy_revoked'))
        elif kind == 'wire_send':
            self.state['latest_wire_ns'] = max(self.state['latest_wire_ns'], data['sent_ns'])
            future = self.state['futures'].get(data['operation_id'])
            if future:
                future['wire'] = dict(data)
        elif kind == 'control_response':
            matches = [f for f in self.state['futures'].values() if response_matches(f, data)]
            if len(matches) != 1:
                outputs.append(response_event(None, data, False, 'unknown_transaction'))
            else:
                future = matches[0]
                duplicate = future['response'] is not None
                if not duplicate:
                    future['response'] = dict(data)
                outputs.append(response_event(future, data, not duplicate, 'duplicate' if duplicate else 'original_future'))
        elif kind == 'operator_finish':
            context = self.state['contexts'].get(self.state['current'])
            if context and finish_matches(context['call'], data):
                context['finish'] = True
        elif kind == 'measurement':
            context = self.state['contexts'].get(self.state['current'])
            if context and not context['cancelled'] and not context['closed']:
                future = self._future(context, 'restore') or self._future(context, 'primary')
                if future:
                    observe(future, data, self.config, self.state['latest_wire_ns'])
        self._continue_current(now, outputs)
        return outputs

    def _continue_current(self, now, outputs):
        context = self.state['contexts'].get(self.state['current'])
        if not context or context['cancelled'] or context['closed']:
            return
        call = context['call']
        primary = self._future(context, 'primary')
        restore = self._future(context, 'restore')
        if not primary:
            return
        if not admission_valid(call, now, self.config):
            # Expiry does not silently create extended restore authority.
            context['closed'] = True
            outputs.append(terminal(call, 'unresolved', restore or primary, 'authority_expired'))
            return
        if restore:
            if restore['response'] and restore['response']['outcome'] == 'failure':
                context['closed'] = True
                outputs.append(terminal(call, 'failed', restore, 'actual_restore_failure'))
            elif has_confirmation(restore, self.config):
                outputs.append(stage_event(call, restore, self.config))
                context['closed'] = True
                outputs.append(terminal(call, 'recovered', restore, 'confirmed_current_workflow', self.config))
            elif restore['wire'] and now-restore['wire']['sent_ns'] > self.config['command_timeout_s']*1e9 and not context['timeout_reported']:
                context['timeout_reported'] = True
                outputs.append(terminal(call, 'unresolved', restore, 'restore_deadline'))
            return
        reason = None
        if has_confirmation(primary, self.config) and not primary['observed']:
            primary['observed'] = True
            outputs.append(stage_event(call, primary, self.config))
        if context['finish'] and 'operator_finish' in call['restore_on']:
            reason = 'operator_finish'
        elif primary['response'] and primary['response']['outcome'] == 'failure' and 'control_failure' in call['restore_on']:
            reason = 'control_failure'
        elif primary['observed'] and 'low_observed' in call['restore_on']:
            reason = 'low_observed'
        elif primary['wire'] and now-primary['wire']['sent_ns'] > self.config['command_timeout_s']*1e9 and 'timeout' in call['restore_on']:
            reason = 'timeout'
        if reason:
            outputs.append(self._issue(context, 'restore', reason, primary['evidence']))

    def authorize_send(self, proposal, now):
        context = self.state['contexts'].get(self.state['current'])
        if not context or context['cancelled'] or context['closed']:
            return False
        call = context['call']
        original = self.state['futures'].get(proposal['operation_id'])
        return bool(original and original['policy_id']==call['policy_id']
                    and original['candidate_id']==call['candidate_id']
                    and original['candidate_version']==call['candidate_version']
                    and original['requested_max_ratio']==proposal['requested_max_ratio']
                    and admission_valid(call, now, self.config))
