"""Retrospective, read-only source-support analysis of retained provenance episodes.

No services, commands or measurements are generated. The frozen analyzer is
imported unchanged. Only a COPY of each 60%-quota action is assigned the existing
low-stage predicate, which was not a prespecified endpoint of the live campaign.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import importlib.util
import json
import statistics
import struct


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
BASE = ROOT / 'data/posthoc/rlc_provenance'
NS = 1_000_000_000


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def jsonl(path):
    return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line]


def midpoint(obj, field):
    return (obj[field + '_before_ns'] + obj[field + '_after_ns']) / 2


def batch_view(report):
    assert report['linkage_status'] == 'exact' and len(report['source_batches']) == 1
    batch = report['source_batches'][0]
    octets = batch['bytes_no_seg'] + batch['bytes_seg']
    nominal_s = report['provider_denominator_seconds']
    assert nominal_s == batch['period_ms'] / 1000 == 1
    exact_kbit_s = octets * 8 / 1000 / nominal_s
    assert exact_kbit_s == report['provider_value_kbit_s']
    assert struct.unpack('f', struct.pack('f', exact_kbit_s))[0] == report['value_kbit_s']
    elapsed = (midpoint(batch, 'snapshot') - midpoint(batch, 'reset_start')) / NS
    return dict(batch_id=batch['batch_id'], representative_report_id=report['report_id'],
                bytes_no_seg=batch['bytes_no_seg'], bytes_seg=batch['bytes_seg'], total_bytes=octets,
                nominal_denominator_s=nominal_s, actual_count_duration_mid_s=elapsed,
                actual_count_duration_lower_s=(batch['snapshot_before_ns']-batch['reset_start_after_ns'])/NS,
                actual_count_duration_upper_s=(batch['snapshot_after_ns']-batch['reset_start_before_ns'])/NS,
                decoded_wire_mbit_s=report['value_kbit_s']/1000,
                provider_mbit_s=exact_kbit_s/1000,
                counts_over_actual_duration_mbit_s=octets*8/1e6/elapsed,
                source=batch, source_refs=report['source_provenance_refs'])


def unique_reports(reports):
    result = {}
    for report in sorted(reports, key=lambda r: r['delivery_mono_ns']):
        assert len(report['source_batches']) == 1
        result.setdefault(report['source_batches'][0]['batch_id'], report)
    return list(result.values())


def steady_summary(reports):
    views = [batch_view(r) for r in reports]
    assert views
    return dict(distinct_batches=len(views), batches=views,
                wire_median_mbit_s=statistics.median(v['decoded_wire_mbit_s'] for v in views),
                wire_min_mbit_s=min(v['decoded_wire_mbit_s'] for v in views),
                wire_max_mbit_s=max(v['decoded_wire_mbit_s'] for v in views),
                actual_wall_rate_median_mbit_s=statistics.median(v['counts_over_actual_duration_mbit_s'] for v in views),
                actual_wall_rate_min_mbit_s=min(v['counts_over_actual_duration_mbit_s'] for v in views),
                actual_wall_rate_max_mbit_s=max(v['counts_over_actual_duration_mbit_s'] for v in views))


def wholly_post_reports(reports, action, next_action, analyzer):
    return unique_reports([r for r in reports
                           if action['wire_mono_ns'] <= r['delivery_mono_ns'] < next_action['wire_mono_ns']
                           and all(analyzer.classify_batch(b, action, r['delivery_mono_ns']) == 'fully_post_application'
                                   for b in r['source_batches'])])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=HERE/'results_v1')
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError('Refusing to overwrite a prior post-hoc readout')
    inputs = {
        'reports': BASE/'analysis/prov-formal-v1/normalized_v1/reports.jsonl',
        'actions': BASE/'analysis/prov-formal-v1/normalized_v1/actions.jsonl',
        'paired_summary': BASE/'analysis/prov-formal-v1/paired_v1/summary.json',
        'plan': BASE/'formal_plan_v1.json',
        'protocol': BASE/'protocol.md',
        'analyzer': BASE/'analyze_provenance.py',
        'provider_source': BASE/'patches/originals/lib/e2/e2sm/e2sm_kpm/e2sm_kpm_du_meas_provider_impl.cpp',
    }
    input_hashes = {str(p.relative_to(ROOT)).replace('\\','/'):sha(p) for p in inputs.values()}
    spec = importlib.util.spec_from_file_location('frozen_provenance_analyzer', inputs['analyzer'])
    analyzer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(analyzer)
    reports, actions = jsonl(inputs['reports']), jsonl(inputs['actions'])
    plan = json.loads(inputs['plan'].read_text(encoding='utf-8'))
    original = json.loads(inputs['paired_summary'].read_text(encoding='utf-8'))
    analyzer.validate_source_consistency(reports)
    runs = [e['run_id'] for e in plan['episodes']]
    assert len(runs) == 12 and set(runs) == {a['run_id'] for a in actions} == {r['run_id'] for r in reports}
    assert len(actions) == 48 and len(reports) == 1067
    original_map = {(a['run_id'],a['action_id']):a['outcomes'] for a in original['actions']}
    # Reproduce ALL existing actions/endpoints exactly before using the evaluator.
    reproduced = 0
    for run in runs:
        aa = sorted([a for a in actions if a['run_id']==run], key=lambda a:a['wire_mono_ns'])
        for i,a in enumerate(aa):
            end = aa[i+1]['wire_mono_ns'] if i+1<len(aa) else None
            _, outcome = analyzer.evaluate_action(a,reports,end)
            assert outcome == original_map[(run,a['action_id'])]
            reproduced += 1
    result = dict(status='completed_posthoc_shadow_analysis',
                  interpretation='New offline use of retained measurements. No actual restoration proposal or E2 action was generated by this analysis.',
                  source_inputs_sha256=input_hashes, script_sha256=sha(Path(__file__)),
                  unchanged_analyzer_original_actions_exactly_reproduced=reproduced,
                  all_planned_episodes_retained=12, reports=1067,
                  original_transition_endpoint='No prespecified low/restoration predicate at 60%; original stage=transition is retained in source data.',
                  posthoc_change='On an in-memory copy only, map stage=transition to stage=low to ask whether the existing low-trigger would qualify. No threshold, clock, ACK, streak, source or horizon guard is changed.',
                  rules='Existing H0/S0 primary; H3full/S3full/H3legacy/S3legacy retained as contextual controls. All use original baseline, <=0.6 baseline, three qualifying observations, increasing exact/declared-precision headers, raw identity, matching ACK, scope, age <=2.5s, and next actual wire command cutoff. Source rules add distinct wholly post-application batches.',
                  episodes=[], aggregates=[])
    all_rows=[]
    for episode in plan['episodes']:
        run = episode['run_id']
        rr = [r for r in reports if r['run_id']==run]
        aa = {a['stage']:a for a in actions if a['run_id']==run}
        transition, restored = aa['transition'],aa['restored']
        shadow = dict(transition,stage='low')
        rows,outcome = analyzer.evaluate_action(shadow,rr,restored['wire_mono_ns'])
        all_rows.extend(rows)
        post = wholly_post_reports(rr,transition,restored,analyzer)
        steady = steady_summary(post)
        support = []
        if outcome['H0']['status']=='confirmed':
            ids = outcome['H0']['supporting_report_ids']
            for rid in ids:
                r=next(r for r in rr if r['report_id']==rid)
                b=r['source_batches'][0]
                support.append(dict(report_id=rid, delivery_after_apply_upper_s=(r['delivery_mono_ns']-transition['apply_after_ns'])/NS,
                                    header_after_apply_lower_s=(r['header_mono_lower_ns']-transition['apply_after_ns'])/NS,
                                    value_mbit_s=r['value_kbit_s']/1000,
                                    source_class=analyzer.classify_batch(b,transition,r['delivery_mono_ns']),
                                    source_start_relative_apply_s=(midpoint(b,'reset_start')-midpoint(transition,'apply'))/NS,
                                    source_snapshot_relative_apply_s=(midpoint(b,'snapshot')-midpoint(transition,'apply'))/NS,
                                    **batch_view(r)))
        result['episodes'].append(dict(**episode, original_action_id=transition['action_id'], original_stage='transition',
            baseline_mbit_s=transition['baseline_kbit_s']/1000, low_threshold_mbit_s=.6*transition['baseline_kbit_s']/1000,
            observation_horizon_after_wire_s=(restored['wire_mono_ns']-transition['wire_mono_ns'])/NS,
            actual_transition_action=transition, outcomes=outcome, H0_support=support,
            fully_post_application_observations=steady,
            fully_post_batches_at_or_below_low_threshold=sum(r['value_kbit_s']<=.6*transition['baseline_kbit_s'] for r in post),
            actual_low_trigger_enabled=False, actual_restoration_caused_by_this_shadow=False))
    for period in (1000,200):
        ee=[e for e in result['episodes'] if e['period_ms']==period]
        assert len(ee)==6
        result['aggregates'].append(dict(period_ms=period, episodes=6,
            confirmed_by_rule={rule:sum(e['outcomes'][rule]['status']=='confirmed' for e in ee) for rule in analyzer.RULES},
            H0_support_class_counts={cl:sum(s['source_class']==cl for e in ee for s in e['H0_support'])
                                     for cl in ('fully_pre_application','crosses_application','fully_post_application')},
            H0_confirmation_after_application_s=[e['outcomes']['H0'].get('seconds_after_apply_upper') for e in ee],
            fully_post_distinct_batches=sum(e['fully_post_application_observations']['distinct_batches'] for e in ee),
            fully_post_low_batches=sum(e['fully_post_batches_at_or_below_low_threshold'] for e in ee),
            fully_post_wire_mbit_s_min=min(e['fully_post_application_observations']['wire_min_mbit_s'] for e in ee),
            fully_post_wire_mbit_s_max=max(e['fully_post_application_observations']['wire_max_mbit_s'] for e in ee)))
    # Retain the existing illustrated example identity; do not select by fit.
    example_run='prov-f1-02-p200'
    aa={a['stage']:a for a in actions if a['run_id']==example_run}
    rr=[r for r in reports if r['run_id']==example_run]
    low=aa['low']
    original_low=original_map[(example_run,low['action_id'])]
    hero_ids=original_low['H0']['supporting_report_ids']
    hero=[r for r in rr if r['report_id'] in hero_ids]
    assert len(hero)==3 and len({r['source_batches'][0]['batch_id'] for r in hero})==1
    crossing=hero[0]; b=crossing['source_batches'][0]
    assert analyzer.classify_batch(b,low,crossing['delivery_mono_ns'])=='crosses_application'
    baseids=low['baseline_validation']['supporting_report_ids']
    pre=[r for r in rr if r['report_id'] in baseids]
    assert len(pre)==5
    post=wholly_post_reports(rr,low,aa['transition'],analyzer)
    pre_summary,post_summary=steady_summary(pre),steady_summary(post)
    before=(midpoint(low,'apply')-midpoint(b,'reset_start'))/NS
    after=(midpoint(b,'snapshot')-midpoint(low,'apply'))/NS
    duration=before+after
    weight=(pre_summary['wire_median_mbit_s']*before+post_summary['wire_median_mbit_s']*after)/duration
    physical_integral=pre_summary['actual_wall_rate_median_mbit_s']*before+post_summary['actual_wall_rate_median_mbit_s']*after
    cv=batch_view(crossing)
    tail=steady_summary(post[-3:])
    result['fig3_weighted_mean']=dict(run_id=example_run, action_id=low['action_id'], supporting_H0_report_ids=hero_ids,
        crossing_batch=cv, pre_duration_mid_s=before, post_duration_mid_s=after,
        pre_duration_lower_s=(low['apply_before_ns']-b['reset_start_after_ns'])/NS,
        pre_duration_upper_s=(low['apply_after_ns']-b['reset_start_before_ns'])/NS,
        post_duration_lower_s=(b['snapshot_before_ns']-low['apply_after_ns'])/NS,
        post_duration_upper_s=(b['snapshot_after_ns']-low['apply_before_ns'])/NS,
        reset_to_reset_mid_s=(midpoint(b,'reset_end')-midpoint(b,'reset_start'))/NS,
        selection='Pre: the original five distinct fully-post-reset baseline observations. Post: every distinct fully-post-20%-application batch delivered before the next real 60% wire command. Late-three post batches are a stated sensitivity check, not a selected successful example.',
        pre=pre_summary, post=post_summary, post_last_three=tail,
        duration_weighted_nominal_wire_rates_mbit_s=weight,
        wire_weighted_minus_observed_mbit_s=weight-cv['decoded_wire_mbit_s'],
        counts_based_piecewise_steady_expected_bits_million=physical_integral,
        counts_based_piecewise_steady_expected_nominal_mbit_s=physical_integral/cv['nominal_denominator_s'],
        counts_based_piecewise_steady_expected_actual_wall_mbit_s=physical_integral/duration,
        counts_based_expected_minus_observed_mbit_s=physical_integral/cv['nominal_denominator_s']-cv['decoded_wire_mbit_s'],
        counts_based_late_three_expected_nominal_mbit_s=(pre_summary['actual_wall_rate_median_mbit_s']*before+tail['actual_wall_rate_median_mbit_s']*after)/cv['nominal_denominator_s'],
        measured_byte_split_at_application_available=False,
        inference='The close weighted-wire-value fit is consistent with mixing, conditional on a piecewise-steady model. It does not identify bytes before/after application. Provider rates use the nominal 1s period, while measured counter intervals are longer; wall-time rates and nominal-period KPM values must be distinguished. Instantaneous transition rates are not measured by these interval counters.')
    # Read-only contract: every input remains byte-identical after analysis.
    assert input_hashes=={str(p.relative_to(ROOT)).replace('\\','/'):sha(p) for p in inputs.values()}
    args.output.mkdir(parents=True)
    (args.output/'summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    with (args.output/'report_decisions.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(all_rows[0])); writer.writeheader();writer.writerows(all_rows)
    print(json.dumps(dict(status=result['status'], episodes=12,aggregates=result['aggregates'],
                         fig3_weighted_nominal=weight, observed=cv['decoded_wire_mbit_s']),indent=2))


if __name__=='__main__':
    main()
