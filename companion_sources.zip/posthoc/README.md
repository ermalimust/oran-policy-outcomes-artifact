# Retrospective source-support analysis

This portable script reuses the 12 formally retained source-provenance episodes. It reproduces all 48 original action outcomes, then evaluates an additional low-threshold endpoint on copies of the 60% transition actions. This endpoint was not enabled during execution. No radio service, proposal or control is generated.

From the supplement folder run:

```text
python -B posthoc/analyze_points_5_6.py --output new_posthoc_output
```

The output path must not exist. All required normalized inputs and the unchanged original evaluator are included under `data/posthoc/rlc_provenance/`. The portable driver differs from the project driver only in ROOT/BASE paths. Reproduced scientific episode and weighted-mean outputs are expected to match `results_retained/summary.json`; input-path and driver hashes necessarily reflect their portable locations. The retained summary has project-relative provenance paths, not internal host paths.

The full byte-for-byte input mapping is in `source_contract.json`. Section 10 explains the retrospective design and the distinction between nominal-period rates, actual counter intervals, shadow confirmations and real actions.
