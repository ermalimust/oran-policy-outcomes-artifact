#!/usr/bin/env python3
"""Independent paired-rule analysis of normalized live provenance evidence.

This script does not create measurements. Required JSONL inputs are joins of
retained raw E2 payloads and instrumented source/scheduler logs. Missing source
provenance remains unknown. See protocol.md for definitions and limitations.
"""
import argparse
import csv
import hashlib
import json
import math
from collections import Counter, defaultdict
from pathlib import Path


RULES = ('H0', 'S0', 'H3full', 'S3full', 'H3legacy', 'S3legacy')
NS = 1_000_000_000


def read_jsonl(path):
    with Path(path).open(encoding='utf-8') as handle:
        return [json.loads(line) for line in handle if line.strip()]


def interval(obj, low, high):
    a, b = obj.get(low), obj.get(high)
    if not isinstance(a, int) or not isinstance(b, int) or a > b:
        return None
    return a, b


def header_interval(report):
    return interval(report, 'header_mono_lower_ns', 'header_mono_upper_ns')


def ntp_order(value):
    """Order original 64-bit headers, never rounded or clock-converted values."""
    if isinstance(value, int):
        return value if 0 <= value < 2**64 else None
    if isinstance(value, str):
        try:
            digits = value.lower().removeprefix('0x')
            parsed = int(digits, 16 if value.lower().startswith('0x') or len(digits) == 16 else 10)
            return parsed if 0 <= parsed < 2**64 else None
        except ValueError:
            return None
    return None


def source_interval(batch):
    start = interval(batch, 'reset_start_before_ns', 'reset_start_after_ns')
    end = interval(batch, 'reset_end_before_ns', 'reset_end_after_ns')
    if not start or not end or start[1] > end[0]:
        return None
    return start, end


def classify_batch(batch, action, delivery_ns):
    window = source_interval(batch)
    application = interval(action, 'apply_before_ns', 'apply_after_ns')
    if not window or not application:
        return 'unknown'
    start, end = window
    if end[1] > delivery_ns:
        return 'invalid_future_source_end'
    if start[0] >= application[1]:
        return 'fully_post_application'
    if end[1] <= application[0]:
        return 'fully_pre_application'
    if start[1] < application[0] and end[0] > application[1]:
        snapshot = interval(batch, 'snapshot_before_ns', 'snapshot_after_ns')
        if snapshot and min(snapshot[0], end[0]) > application[1]:
            return 'crosses_application'
        return 'reset_interval_crosses_but_snapshot_not_proven_after_application'
    return 'uncertain_boundary_overlap'


def finite_number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def source_eligibility(report, action, used_batches):
    if report.get('linkage_status') != 'exact':
        return False, 'source_link_unknown'
    batches = report.get('source_batches', [])
    if not batches or any(not b.get('batch_id') for b in batches):
        return False, 'missing_source_batch'
    ids = [str(b['batch_id']) for b in batches]
    if len(set(ids)) != len(ids):
        return False, 'duplicate_batch_inside_report'
    classes = [classify_batch(b, action, report['delivery_mono_ns']) for b in batches]
    if any(c != 'fully_post_application' for c in classes):
        return False, 'source_interval_' + ','.join(sorted(set(classes)))
    if used_batches.intersection(ids):
        return False, 'reused_source_batch'
    return True, 'eligible'


def evaluate_action(action, reports, next_wire_ns=None):
    """Evaluate in actual delivery/ACK order, retaining every report decision."""
    states = {r: dict(streak=[], used_batches=set(), last_header_ntp=None,
                     seen_raw=set(), confirmation=None)
              for r in RULES}
    rows = []
    threshold_fraction = 0.6 if action.get('stage') == 'low' else 0.8
    if action.get('stage') not in ('low', 'restored'):
        return rows, {r: dict(status='not_a_confirmation_stage') for r in RULES}
    baseline = action.get('baseline_kbit_s')
    if not finite_number(baseline) or baseline <= 0:
        return rows, {r: dict(status='missing_baseline') for r in RULES}
    application = interval(action, 'apply_before_ns', 'apply_after_ns')
    wire = action['wire_mono_ns']
    end = next_wire_ns if next_wire_ns is not None else action.get('observation_end_ns', 2**63-1)
    selected = [r for r in reports if wire <= r['delivery_mono_ns'] < end]
    events = [(r['delivery_mono_ns'], 1, r) for r in selected]
    ack = action.get('ack_mono_ns')
    if isinstance(ack, int) and wire <= ack < end and action.get('ack_outcome', 'acknowledge') == 'acknowledge':
        events.append((ack, 0, None))
    ack_seen = False
    for event_ns, kind, report in sorted(events, key=lambda x: (x[0], x[1])):
        if kind == 0:
            ack_seen = True
            for name, state in states.items():
                if state['confirmation'] is None and len(state['streak']) >= 3:
                    state['confirmation'] = confirmation(event_ns, state['streak'])
            continue
        raw = report.get('raw_payload_sha256')
        header_raw = report.get('header_ntp_raw')
        classes = [classify_batch(b, action, report['delivery_mono_ns'])
                   for b in report.get('source_batches', [])]
        common_reason = None
        if any(report.get(k) != action.get(k) for k in ('run_id', 'node_id', 'ue_id', 'metric')):
            common_reason = 'scope_mismatch'
        elif action.get('subscription_id') is not None and report.get('subscription_id') != action['subscription_id']:
            common_reason = 'subscription_mismatch'
        elif not raw or ntp_order(header_raw) is None or not report.get('report_id'):
            common_reason = 'missing_raw_identity'
        elif not finite_number(report.get('value_kbit_s')):
            common_reason = 'nonfinite_value'
        value = report.get('value_kbit_s')
        qualifies = (finite_number(value) and
                     (value <= baseline*threshold_fraction if action['stage'] == 'low'
                      else value >= baseline*threshold_fraction))
        for name, state in states.items():
            reason = common_reason
            legacy = name.endswith('legacy')
            header = (interval(report, 'header_legacy_mono_lower_ns', 'header_legacy_mono_upper_ns')
                      if legacy else header_interval(report))
            header_order = ntp_order(header_raw)
            if legacy and header_order is not None:
                header_order >>= 32
            if reason is None and header is None:
                reason = 'header_clock_unknown'
            elif reason is None and (report['delivery_mono_ns'] < header[1]
                    or report['delivery_mono_ns']-header[0] > int(2.5*NS)):
                reason = 'header_age_outside_bound'
            if reason is None and raw in state['seen_raw']:
                reason = 'duplicate_raw_indication'
            if reason is None and state['last_header_ntp'] is not None and header_order <= state['last_header_ntp']:
                reason = 'header_not_strictly_increasing'
            if reason is None:
                if name.endswith('0'):
                    if not application:
                        reason = 'application_unknown'
                    elif header[0] <= application[1]:
                        reason = 'header_not_after_application'
                elif header[0] < wire + 3*NS:
                    reason = 'header_before_three_second_guard'
            if reason is None and name.startswith('S'):
                eligible, why = source_eligibility(report, action, state['used_batches'])
                if not eligible:
                    reason = why
            # The previous implemented leaf predicate updates last_header only
            # for eligible observations; reproduce that ordering independently.
            if reason is None:
                state['seen_raw'].add(raw)
                state['last_header_ntp'] = header_order
                if qualifies:
                    state['streak'].append(report)
                    state['streak'] = state['streak'][-3:]
                    state['used_batches'] = {str(b['batch_id']) for item in state['streak']
                                             for b in item.get('source_batches', []) if b.get('batch_id')}
                else:
                    state['streak'] = []
                    state['used_batches'] = set()
                reason = 'qualifying' if qualifies else 'threshold_miss'
            if state['confirmation'] is None and ack_seen and len(state['streak']) >= 3:
                state['confirmation'] = confirmation(event_ns, state['streak'])
            rows.append(dict(run_id=action['run_id'], action_id=action['action_id'],
                             report_id=report['report_id'], rule=name,
                             delivery_mono_ns=event_ns, header_ntp_raw=header_raw,
                             value_kbit_s=value, reason=reason,
                             source_classes=';'.join(classes),
                             batch_ids=';'.join(str(b.get('batch_id', '')) for b in report.get('source_batches', [])),
                             streak_length=len(state['streak']),
                             confirmed=state['confirmation'] is not None))
    result = {}
    for name, state in states.items():
        item = state['confirmation']
        if item:
            result[name] = dict(status='confirmed', **item,
                                seconds_after_wire=(item['confirmation_mono_ns']-wire)/NS,
                                seconds_after_apply_upper=(item['confirmation_mono_ns']-application[1])/NS if application else None)
            support = [r for r in selected if r['report_id'] in item['supporting_report_ids']]
            linked = all(r.get('linkage_status') == 'exact' and r.get('source_batches') for r in support)
            classes = [classify_batch(b, action, r['delivery_mono_ns']) for r in support
                       for b in r.get('source_batches', [])]
            if not linked or any(c == 'unknown' for c in classes):
                provenance = 'unknown'
            elif (all(c == 'fully_post_application' for c in classes)
                  and item['distinct_source_batch_count'] >= 3
                  and len(item['supporting_batch_ids']) == item['distinct_source_batch_count']):
                provenance = 'three_distinct_fully_post_application_observations'
            else:
                provenance = 'does_not_meet_three_distinct_fully_post_application_criterion'
            result[name]['supporting_source_criterion'] = provenance
            result[name]['supporting_source_classes'] = classes
        else:
            result[name] = dict(status='unresolved', final_streak_length=len(state['streak']),
                                missing_successful_ack=not ack_seen)
    for h, s in (('H0', 'S0'), ('H3full', 'S3full'), ('H3legacy', 'S3legacy')):
        hc, sc = result[h].get('confirmation_mono_ns'), result[s].get('confirmation_mono_ns')
        result[h+'_versus_'+s] = dict(
            additional_wait_seconds=(sc-hc)/NS if hc is not None and sc is not None else None,
            header_confirmed_source_unresolved=hc is not None and sc is None,
            source_unconfirmed_at_header_confirmation=hc is not None and (sc is None or sc > hc))
    return rows, result


def confirmation(event_ns, streak):
    batches = [str(b['batch_id']) for r in streak for b in r.get('source_batches', []) if b.get('batch_id')]
    return dict(confirmation_mono_ns=event_ns,
                supporting_report_ids=[r['report_id'] for r in streak],
                supporting_payload_sha256=[r['raw_payload_sha256'] for r in streak],
                supporting_batch_ids=batches, distinct_source_batch_count=len(set(batches)))


def coverage(reports):
    exact = [r for r in reports if r.get('linkage_status') == 'exact']
    by_batch = defaultdict(list)
    for report in exact:
        for batch in report.get('source_batches', []):
            if batch.get('batch_id'):
                by_batch[(report['run_id'], str(batch['batch_id']))].append(report)
    reused = []
    for (run_id, batch_id), items in by_batch.items():
        unique = {}
        for item in items:
            if item.get('header_ntp_raw') and item.get('raw_payload_sha256'):
                unique.setdefault(item['header_ntp_raw'], item)
        if len(unique) >= 2:
            reused.append(dict(run_id=run_id, batch_id=batch_id,
                               distinct_header_count=len(unique),
                               reports=[dict(report_id=r['report_id'], header_ntp_raw=r['header_ntp_raw'],
                                             raw_payload_sha256=r['raw_payload_sha256'],
                                             raw_header_ref=r.get('raw_header_ref'),
                                             source_provenance_refs=r.get('source_provenance_refs', []))
                                        for r in unique.values()]))
    return dict(report_count=len(reports), exact_link_count=len(exact),
                linkage_status_counts=dict(Counter(r.get('linkage_status', 'missing') for r in reports)),
                distinct_raw_header_count=len({(r['run_id'], r.get('header_ntp_raw')) for r in reports if r.get('header_ntp_raw')}),
                distinct_batch_count=len(by_batch),
                batches_reused_under_distinct_headers=len(reused), repeated_source_examples=reused)


def validate_source_consistency(reports):
    """A source batch cannot acquire a different window when reused in KPM."""
    seen = {}
    fields = ('reset_start_before_ns', 'reset_start_after_ns',
              'reset_end_before_ns', 'reset_end_after_ns',
              'snapshot_before_ns', 'snapshot_after_ns',
              'bytes', 'bytes_no_seg', 'bytes_seg', 'period_ms')
    for report in reports:
        for batch in report.get('source_batches', []):
            if not batch.get('batch_id'):
                continue
            key = report['run_id'], str(batch['batch_id'])
            values = {k: batch.get(k) for k in fields}
            if key in seen and seen[key] != values:
                raise ValueError('Inconsistent source metadata for batch {} in report {}'.format(key, report['report_id']))
            seen[key] = values


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reports', type=Path, required=True)
    parser.add_argument('--actions', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    reports, actions = read_jsonl(args.reports), read_jsonl(args.actions)
    if not reports:
        raise ValueError('No measured reports supplied; refusing an empty success output')
    identities = [(r['run_id'], r['report_id']) for r in reports]
    if len(set(identities)) != len(identities):
        raise ValueError('Duplicate run/report identity in normalized input')
    validate_source_consistency(reports)
    if args.output.exists() and any(args.output.iterdir()):
        raise FileExistsError('Refusing to overwrite existing analysis evidence')
    args.output.mkdir(parents=True, exist_ok=True)
    result = dict(schema_version=1,
                  interpretation='Offline paired evaluation of actual observations; source metadata is test instrumentation, not existing E2 fields. No online source-aware latency or record superiority is measured.',
                  source_inputs={str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in (args.reports, args.actions)},
                  analysis_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  coverage=coverage(reports), episodes={}, actions=[])
    for run_id in sorted({r['run_id'] for r in reports}):
        result['episodes'][run_id] = coverage([r for r in reports if r['run_id'] == run_id])
    rows = []
    by_scope = defaultdict(list)
    for action in actions:
        by_scope[(action['run_id'], action.get('node_id'), action.get('ue_id'))].append(action)
    for scope_actions in by_scope.values():
        ordered = sorted(scope_actions, key=lambda a: a['wire_mono_ns'])
        for index, action in enumerate(ordered):
            next_wire = ordered[index+1]['wire_mono_ns'] if index+1 < len(ordered) else None
            action_rows, outcome = evaluate_action(action, reports, next_wire)
            rows.extend(action_rows)
            result['actions'].append(dict(action_id=action['action_id'], run_id=action['run_id'],
                                          stage=action.get('stage'), target_max_ratio=action.get('target_max_ratio'),
                                          outcomes=outcome))
    (args.output/'summary.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    if rows:
        with (args.output/'report_decisions.csv').open('w', encoding='utf-8', newline='') as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    print(json.dumps(dict(reports=len(reports), actions=len(actions), output=str(args.output),
                          reused_batches=result['coverage']['batches_reused_under_distinct_headers'])))


if __name__ == '__main__':
    main()
