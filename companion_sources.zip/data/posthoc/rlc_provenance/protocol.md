# Focused RLC provenance experiment

Protocol version: `rlc-provenance-v1`, prepared 12 November 2026. This is a new instrumented campaign, not a replacement for the frozen round-two evidence. Before measured execution, retain this file's SHA-256, the run matrix, source commit, instrumentation patch, binary, configuration, runner, and analysis hashes. Development attempts and changes remain separately labelled. Preparation is not evidence of execution or success.

## Question and claims

1. Does a newly encoded KPM header refer to an RLC source batch already used by an earlier report in this actual implementation?
2. After an actual scheduler configuration update, does accounting for the source interval and repeated batches change a three-observation confirmation decision on the same received KPM sequence?

The first claim requires a direct join from retained raw E2 indication/header bytes to the actual source batch selected by the KPM provider. Merely similar throughput values, report timestamps, or a nominal-period subtraction do not establish the claim. The second claim requires actual counter-reset brackets and scheduler-application brackets. An interval crossing a configuration boundary establishes timing overlap, not that payload bytes from both configurations contributed to its value. This experiment does not establish record-format superiority, production reliability, an optimal waiting time, or independent field trials.

## Platform and instrumentation boundary

Use the existing single-UE software radio platform (OCUDU gNB, srsUE, ZeroMQ, Open5GS, and O-RAN SC RIC) at the retained pinned versions. Keep actual RLC statistics periodicity at 1,000 ms and offered UDP downlink load at 80 Mbit/s. The instrumented gNB is a separately identified binary. Preserve the original source, binary, nine frozen episodes, and missing-window fields in previous data.

Record at the actual low-TX byte-counter reset: process/boot epoch, UE/bearer/entity identity, source counter/batch identity, PDU byte count, previous reset's before/after monotonic clock readings, and current reset's before/after readings. Record the batch the provider actually reads, including a multi-batch list if it aggregates more than one. Record the KPM collection/report association and the exact encoded header. Do not use the collector's top-level constant-zero counter as a batch ID. A first batch with no observed preceding reset has unknown start and cannot be classified as a fully post-update interval.

Record actual scheduler configuration application immediately around the relevant configuration updates, with UE, quota, local generation, before/after monotonic readings, and wall-clock readings. Control transmission, gNB receipt, ACK, configuration application, first evaluation of limits, a successful grant, and received user traffic remain separate events. An optional first-limit-use event must not be called a successful grant.

All provenance fields are test-instrumentation metadata. They are not advertised as existing standard E2 fields or information already available to the prior controller. They must not change the metric's counter, denominator, control validation, or scheduling policy.

## Clock and identity joins

Use one host monotonic clock domain for source resets, application, and receipt. Retain explicit clock samples bracketing wall-clock reads; map the full NTP seconds and fraction to a monotonic interval with the observed clock-offset envelope. This envelope is empirical and conditional on no unobserved clock discontinuity, not a deterministic drift bound. Also retain the direct monotonic bracket around the original header's system-clock read, linked by the exact NTP identity. Preserve both the literal timestamp carried on wire and the actual creation bracket. The pinned encoder multiplies microseconds by the integer quotient `(2^32)/10^6 = 4294`; this introduces a fraction bias of up to approximately 225 microseconds, plus sub-microsecond truncation. Record it rather than silently correcting the wire timestamp. Retain raw bytes, decoder version, raw-payload digest, subscription and UE/metric identity. A join by approximate timestamp alone is insufficient. Where exact encoded header linkage is ambiguous, keep the report and mark its source linkage unknown.

The implementation can pack the indication message, clear/update collection state, and only then pack the indication header. Consequently, the collection-time header is not assumed to equal the transmitted header. Join provider collection records to the packed message and its pack ID, then to `kpm_header_pack`'s actual encoded header, and finally to the retained E2 payload. The independent analysis consumes that wire header.

The provider computes throughput as a C++ double, then assigns it to the pinned ASN.1 `real_s.value` float field. The retained type definition is in `patches/asn1_real_type_source.txt` (original `include/ocudu/asn1/asn1_utils.h:1638`); the assignment is retained in the original KPM provider source under `patches/originals`. Validate the decoded wire value against the exact IEEE-754 float32 conversion of the provider double, not against a broadened numeric tolerance. Preserve the provider value, expected serialized value, and rounding difference. All confirmation thresholds use the actual decoded wire value.

The source batch ID includes an epoch and source entity/UE/bearer identity plus a counter; a counter by itself is not globally unique. More than one header may legitimately link to the same batch. A raw indication retransmission is separately identified and must not count as a new observation.

## Fixed small matrix

Use KPM reporting/collection periods of **1,000 ms** (the previous setting) and **200 ms** (an explicitly changed, faster-reporting diagnostic condition). For each period, schedule the first 20% command at **0.1, 0.4, and 0.7 s** after an observed actual source reset; repeat each cell twice, giving **12 episodes**. Requested phase is a scheduling target, not a measured fact. Record and report actual phase relative to the reset bracket, and preserve misses; do not move an episode to a more favourable phase bin after seeing decisions.

Interleave cells before execution: repetition 1 uses 1000/0.1, 200/0.4, 1000/0.7, 200/0.1, 1000/0.4, 200/0.7; repetition 2 reverses this order. Each episode is a separate subscription/retained episode identity; repeated episodes still share one host and UE and are not independent network deployments.

1. Reset to maximum quota 100% through actual E2 control, retain the ACK and actual application, and observe at least five **distinct**, fully post-reset source batches under sustained load. Fix the episode baseline to their median KPM throughput. Require positive finite values, median at least 47,000 kbit/s, and maximum/minimum no greater than 1.10. An unsuccessful baseline is retained as a failed attempt, not silently replaced. All retries get new IDs and reasons.
2. Retain the baseline steady segment for the header/batch reuse question.
3. At the assigned phase, send 20%, then 60%, then 100% through real E2, dwelling 8 s after each application. Retain all indications, controls, ACKs, source records, scheduler records, and independent packet evidence. If an application is missing, mark the attempt incomplete; do not infer it from the ACK. A bounded infrastructure timeout must leave logs intact.
4. Low-state confirmation is tested for the 20% action at <=60% of the fixed baseline. Restored-state confirmation is tested for the final 100% action at >=80%. The 60% action is a transition for interval provenance; it has no invented service-completion predicate.

If runtime constraints require a different matrix, change and freeze a new protocol version before those measured episodes. No favourable development observation is silently promoted to a predeclared measured episode.

## Paired decision definitions

These are independent, offline evaluations of the same actual reports. They do not import the tested controller's decision function. Confirmation time is indexed to original report/ACK receipt. It is not a measured online latency of a new source-aware controller; real delivery and processing of the additional provenance would need separate measurement.

All rules require the same UE/subscription/metric, distinct raw indications, strictly increasing headers at the explicitly specified decoder precision, finite throughput, an unambiguous action scope with no subsequent control sent before the decision, matching successful ACK, three consecutive qualifying observations, and delivery-minus-header age within 0 to 2.5 s. A threshold miss resets the qualifying streak. An ineligible report does not add an observation. An ACK arriving after observations can complete the current qualifying streak, provided no intervening report has invalidated it. Count three observations under both rules; source-aware observations must additionally represent three distinct batches.

- **H0, header after application:** require the lower bound of the header time to be after the upper bound of actual configuration application.
- **S0, source-aware:** apply H0 and additionally require exact source linkage, each contributing source interval wholly after application, no conflicting application inside that interval, and no contributing batch reused in the qualifying streak. This isolates the effect of source provenance; it is not presented as the old controller's implemented rule.
- **H3full, full-precision quiet-time diagnostic:** use header-at-least-3-s-after-wire in place of H0's after-application test, with the same other checks and full precision. This is not the exact historical decoder behavior.
- **S3full, source-aware addition to H3full:** add the same source eligibility as S0.
- **H3legacy, retained controller precision:** reproduce the previous decoder's omission of the NTP fraction. Use the whole-second timestamp for the 3 s guard, age filter, and strict-increase check. In particular, two distinct raw headers within the same second cannot count as two observations under this rule.
- **S3legacy, source-aware addition to H3legacy:** add the same source eligibility as S0. Report agreement if the old coarse-header/quiet-time combination already prevented the discrepancy in these cases. None of these finite runs converts the original source-liveness assumption into a deterministic bound.

For conservative timing classification, let a batch start reset lie in [s_lo,s_hi], its end reset in [e_lo,e_hi], its counter snapshot in [q_lo,q_hi], and application in [a_lo,a_hi]. Classify as definitely post-application only if s_lo >= a_hi. Classify as definitely pre-application if e_hi <= a_lo. Classify as definitely crossing only if s_hi < a_lo and min(q_lo,e_lo) > a_hi. This prevents the gap between copying counters and resetting them from being misrepresented as support in the copied measurement. All other overlap with an uncertainty bracket is uncertain, not a manufactured exact boundary. A batch whose end lies after report receipt or with missing/reset-inconsistent fields is unusable and flagged.

## Outputs and integrity checks

Retain raw trace, raw E2 payloads/packet capture, source and scheduler log records, configuration, code/binary hashes, load output, complete attempt ledger, and a normalized join with raw references. Every analysed report includes its header bytes, source batch list, interval brackets, linkage status, and derivation references. Every action includes wire, ACK, application and baseline evidence references.

The analysis interface is JSONL. Report fields are `run_id`, `report_id`, `node_id`, `ue_id`, `metric`, optional `subscription_id`, `raw_payload_sha256`, `header_ntp_raw` (the exact 64-bit integer or 16-digit hex), `header_mono_lower_ns`, `header_mono_upper_ns`, `header_legacy_mono_lower_ns`, `header_legacy_mono_upper_ns`, `delivery_mono_ns`, `value_kbit_s`, `linkage_status`, `raw_header_ref`, `source_provenance_refs`, and `source_batches`. Each source batch has a fully qualified `batch_id`, `reset_start_before_ns`, `reset_start_after_ns`, `reset_end_before_ns`, `reset_end_after_ns`, `snapshot_before_ns`, `snapshot_after_ns`, and retained counter values. Unknown first-window starts remain null. Actual header creation brackets are retained separately from literal decoded timestamps. Action fields are `run_id`, `action_id`, the same scope, `target_max_ratio`, `wire_mono_ns`, `ack_mono_ns`, `ack_outcome`, `apply_before_ns`, `apply_after_ns`, `observation_end_ns`, `baseline_kbit_s`, and `stage` (`low`, `restored`, or `transition`). Preserve extra raw-reference and clock-calibration fields alongside these. Input normalization is not permission to fabricate missing metadata.

Report, by episode and reporting period:

- observed report count, distinct raw headers, uniquely linked reports, unknown/ambiguous links, and distinct source batches;
- pairs of distinct headers that actually reused a source batch, with inspectable raw evidence;
- pre-update, crossing, fully post-update and uncertain source intervals;
- each rule's three supporting report/batch IDs, confirmation or unresolved outcome, original receipt time, and paired additional wait when both confirm;
- header-based confirmations that lacked three distinct fully post-application batches at that time (a provenance violation under the defined criterion, not a proven incorrect radio/SLA outcome);
- baseline failures, phase misses, missing ACK/application, instrumentation errors and all unsuccessful attempts.

Do not drop an episode because the rules agree. Agreement is a legitimate finding. Repetition characterizes local repeatability, not a reliability probability. RLC source age and header age remain separate quantities. Inspect a small set of differing decisions directly against raw bytes and instrumentation records before presenting a claimed result.
